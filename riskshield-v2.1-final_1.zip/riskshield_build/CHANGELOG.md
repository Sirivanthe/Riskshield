# RiskShield Changelog

## v2.1.0 — 2026-04-19 (Current)

### 🔒 Security (P0)
- **Rate limiting** — token bucket limiter: 10 auth req/min per IP, 300 API req/min. Returns structured 429 with retry info.
- **Prompt injection defence** — regex pattern matching on all user-supplied text fields before any LLM call. Returns 400 `INJECTION_DETECTED` on match.
- **Immutable audit log** — every auth event, data mutation, admin action and LLM call written to `audit_log` collection. Admin-only `/api/audit-log` endpoint with pagination and category/actor filters.
- **Control version history** — full before/after snapshots on every CREATE/UPDATE/DELETE. `/api/control-analysis/controls/:id/history` endpoint.
- **Fernet key rotation** — `services/fernet_rotation.py` utility with dry-run mode. `bash scripts/rotate-key.sh`.
- **Security headers** — `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff` on all responses.
- **Request IDs** — `X-Request-ID` UUID header on every response for tracing.

### 🏗️ Architecture (P1)
- **Emergent platform purge** — all 73 `emergentintegrations`, `EMERGENT_LLM_KEY`, `EmergentLLMClient` references removed from 23 files.
- **Direct LLM SDKs** — `llm_client.py` fully rewritten using Anthropic, OpenAI, Gemini SDKs directly. No third-party wrapper.
- **`llm_evaluator.py` rewrite** — direct `anthropic` SDK with `asyncio.run_in_executor` for async compatibility. All 5 evaluation functions preserved.
- **Persistent job queue** — `services/job_queue.py` SQLite/MongoDB-backed queue replaces daemon thread for assessment jobs. Jobs survive restarts. Retry support (3 attempts).
- **Input validation service** — `services/input_validation.py` with sanitisation, length limits, and injection detection.
- **New services** — `rate_limiter.py`, `audit_log.py`, `control_history.py`, `job_queue.py`, `input_validation.py`, `fernet_rotation.py`.
- **WAL mode** — SQLite connections use `PRAGMA journal_mode=WAL` for better concurrent access.

### 🚀 API (P1/P2)
- **Pagination** — all list endpoints support `?page=N&limit=N`, return `{items, total, page, pages}`.
- **Filtering** — `GET /issues?status=OPEN&severity=HIGH&priority=HIGH`.
- **Structured errors** — all errors return `{"error": {"code": "ERROR_CODE", "message": "..."}}`. Never leaks stack traces.
- **New endpoints** — `POST /auth/logout`, `POST /auth/change-password`, `GET /control-analysis/controls/:id/history`, `GET /audit-log`, `POST /admin/users`, `GET /admin/jobs`.
- **LOD2 permissions** — LOD2 can delete controls; LOD1 cannot.
- **Duplicate user detection** — `POST /admin/users` returns 409 on duplicate email.

### 🔧 Dev Experience
- **Local server** — `backend/local_server.py` (Flask + SQLite, zero install needed) replaces MongoDB requirement for local dev.
- **Scripts** — `scripts/setup.sh`, `start.sh`, `stop.sh`, `rotate-key.sh`.
- **Clean `.env.example`** — all variables documented with comments.
- **Docker Compose** — health checks on all services, FAISS volume persistence.
- **`.gitignore`** — secrets, DBs, node_modules all excluded.

### 🐛 Bug Fixes
- Fixed `KeyError: 'domain'` in knowledge graph endpoint.
- Fixed `emergentintegrations` import error crashing all LLM calls on fresh install.
- Fixed hardcoded `sk-emergent-...` API key in documents route.
- Fixed `LLMProvider.EMERGENT` enum causing validation errors.
- Fixed duplicate `ANTHROPIC` enum entry in models.
- Fixed audit write DB lock causing 500 errors on concurrent requests.

---

## v2.0.0 — 2026-04-19

- Initial platform build via Emergent.sh
- 44 development iterations
- Full GRC feature set: Assessments, Controls, Issues, Tech Risk, Regulatory Analysis, RCM Testing, Trend Analytics, Knowledge Graph, Observability, Multi-tenancy, ServiceNow integration
