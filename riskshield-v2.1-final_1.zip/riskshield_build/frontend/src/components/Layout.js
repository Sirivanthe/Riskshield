import { useEffect, useState } from 'react';
import { Outlet, NavLink } from 'react-router-dom';
import { api } from '@/App';

const Icon = ({ children, size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    {children}
  </svg>
);

const NAV = (user) => [
  { group: null, items: [
    { to: '/', label: 'Command Centre', exact: true, badge: null, icon: <Icon><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></Icon> },
    { to: '/my-work', label: 'My Work', badge: 'total', icon: <Icon><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></Icon> },
  ]},
  { group: 'Plan & Assess', items: [
    { to: '/assessments', label: 'Assessments', icon: <Icon><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></Icon> },
    { to: '/tech-risk-assessment', label: 'Tech Risk', icon: <Icon><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></Icon> },
    { to: '/ai-compliance', label: 'AI Compliance', icon: <Icon><circle cx="12" cy="12" r="3"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4"/></Icon> },
  ]},
  { group: 'Controls & Testing', items: [
    { to: '/controls-library', label: 'Controls Library', icon: <Icon><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></Icon> },
    { to: '/automated-testing', label: 'Automated Testing', icon: <Icon><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 14l2 2 4-4"/></Icon> },
    { to: '/rcm-testing', label: 'RCM Testing', icon: <Icon><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></Icon> },
  ]},
  { group: 'Analysis', items: [
    { to: '/control-analysis', label: 'Control Analysis', icon: <Icon><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></Icon> },
    { to: '/regulatory-analysis', label: 'Regulatory Analysis', icon: <Icon><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></Icon> },
    { to: '/gap-remediation', label: 'Gap Remediation', icon: <Icon><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></Icon> },
  ]},
  { group: 'Remediation', items: [
    { to: '/issue-management', label: 'Issue Management', badge: 'overdue_issues', icon: <Icon><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></Icon> },
    { to: '/workflows', label: 'Workflows', icon: <Icon><path d="M13 10V3L4 14h7v7l9-11h-7z"/></Icon> },
  ]},
  { group: 'Intelligence', items: [
    { to: '/trend-analytics', label: 'Trend Analytics', icon: <Icon><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></Icon> },
    { to: '/knowledge-graph', label: 'Knowledge Graph', icon: <Icon><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></Icon> },
    { to: '/observability', label: 'Observability', icon: <Icon><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></Icon> },
    { to: '/agent-activity', label: 'Agent Activity', icon: <Icon><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></Icon> },
  ]},
  ...(user?.role === 'ADMIN' || user?.role === 'LOD2' ? [{ group: 'System', items: [
    { to: '/admin', label: 'Admin', icon: <Icon><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></Icon> },
  ]}] : []),
];

const initials = (name = '') => name.split(' ').map(p => p[0]).join('').toUpperCase().slice(0, 2) || '??';

const Layout = ({ user, onLogout }) => {
  const [counts, setCounts] = useState({ total: 0, overdue_issues: 0 });

  useEffect(() => {
    let alive = true;
    const load = () => api.get('/my-work/count').then(r => { if (alive) setCounts(r.data); }).catch(() => {});
    load();
    const t = setInterval(load, 30000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  const Badge = ({ k }) => {
    const n = counts?.[k];
    if (!n) return null;
    return (
      <span className="nav-badge" data-testid={`nav-badge-${k}`}
        style={{ background: k === 'overdue_issues' ? 'rgba(255,92,92,0.18)' : 'rgba(91,143,249,0.18)', color: k === 'overdue_issues' ? '#ff7070' : '#7aa6ff' }}>
        {n}
      </span>
    );
  };

  return (
    <div className="layout">
      <aside className="sidebar" data-testid="sidebar">
        {/* Amber top rule from CSS ::before */}
        <div className="sidebar-header">
          <NavLink to="/" className="sidebar-logo" data-testid="sidebar-logo">
            <div className="logo-icon">RS</div>
            <div className="logo-wordmark">
              <span className="logo-name">RiskShield</span>
              <span className="logo-sub">GRC Platform</span>
            </div>
          </NavLink>

          <div className="user-badge" data-testid="user-badge">
            <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--accent-dim)', border: '1px solid rgba(245,174,60,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: 'var(--accent)', fontFamily: 'var(--font-mono)', flexShrink: 0 }}>
                {initials(user?.full_name)}
              </div>
              <div>
                <div className="user-name" data-testid="user-badge">{user?.full_name}</div>
                <div className="user-meta">
                  <span className="user-role" data-testid="user-role-badge">{user?.role}</span>
                  {user?.business_unit && <span className="user-unit">{user.business_unit}</span>}
                </div>
              </div>
            </div>
          </div>
        </div>

        <nav className="sidebar-nav" data-testid="sidebar-nav">
          {NAV(user).map((group, gi) => (
            <div key={gi} className="nav-group" data-testid={`nav-group-${gi}`}>
              {group.group && <span className="nav-group-label">{group.group}</span>}
              {group.items.map(it => (
                <NavLink key={it.to} to={it.to} end={it.exact}
                  className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}
                  data-testid={`nav-${it.label.toLowerCase().replace(/\s+/g,'-')}`}>
                  {it.icon}
                  <span style={{ flex: 1 }}>{it.label}</span>
                  {it.badge && <Badge k={it.badge} />}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-footer">
          <button className="logout-button" onClick={onLogout} data-testid="logout-button">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4m7 14l5-5-5-5m5 5H9"/>
            </svg>
            Sign out
          </button>
        </div>
      </aside>

      <main className="main-content">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
