import { useState, useEffect } from 'react';
import { api } from '@/App';

const API_URL = process.env.REACT_APP_BACKEND_URL;

const SEV_COLOR = { CRITICAL:'var(--color-critical)', HIGH:'var(--color-high)', MEDIUM:'var(--color-medium)', LOW:'var(--color-low)', INFO:'var(--color-info)' };
const SEV_BG    = { CRITICAL:'var(--bg-critical)', HIGH:'var(--bg-high)', MEDIUM:'var(--bg-medium)', LOW:'var(--bg-low)', INFO:'var(--bg-info)' };

const Badge = ({ type, val }) => {
  if (!val) return null;
  const v = val.toUpperCase();
  const colorMap = type === 'severity' ? SEV_COLOR : { OPEN:'var(--color-info)', IN_PROGRESS:'var(--color-medium)', RESOLVED:'var(--color-low)', CLOSED:'var(--text-tertiary)' };
  const bgMap    = type === 'severity' ? SEV_BG    : { OPEN:'var(--bg-info)', IN_PROGRESS:'var(--bg-medium)', RESOLVED:'var(--bg-low)', CLOSED:'rgba(77,99,133,0.2)' };
  return (
    <span style={{ display:'inline-flex', alignItems:'center', padding:'2px 8px', borderRadius:4, fontSize:10, fontWeight:700, letterSpacing:'0.05em', textTransform:'uppercase', fontFamily:'var(--font-mono)', background: bgMap[v] || 'var(--bg-elevated)', color: colorMap[v] || 'var(--text-secondary)' }}>
      {val.replace('_',' ')}
    </span>
  );
};

const initials = (n='') => n.split(' ').map(p=>p[0]).join('').toUpperCase().slice(0,2)||'??';

const IssueManagement = ({ user }) => {
  const [issues, setIssues]           = useState([]);
  const [stats, setStats]             = useState(null);
  const [selected, setSelected]       = useState(null);
  const [loading, setLoading]         = useState(true);
  const [filters, setFilters]         = useState({ status:'', severity:'' });
  const [showCreate, setShowCreate]   = useState(false);
  const [comment, setComment]         = useState('');
  const [submitting, setSubmitting]   = useState(false);
  const [newIssue, setNewIssue]       = useState({ title:'', description:'', severity:'MEDIUM', priority:'MEDIUM', type:'CONTROL_GAP', owner:'' });

  useEffect(() => { fetchIssues(); fetchStats(); }, [filters]);

  const token = () => localStorage.getItem('token');

  const fetchIssues = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.status)   params.append('status', filters.status);
      if (filters.severity) params.append('severity', filters.severity);
      params.append('limit', 100);
      const r = await fetch(`${API_URL}/api/issues?${params}`, { headers: { Authorization: `Bearer ${token()}` } });
      const d = await r.json();
      setIssues(d.items || d || []);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const fetchStats = async () => {
    try {
      const r = await fetch(`${API_URL}/api/issues/stats`, { headers: { Authorization: `Bearer ${token()}` } });
      setStats(await r.json());
    } catch {}
  };

  const createIssue = async (e) => {
    e.preventDefault(); setSubmitting(true);
    try {
      const r = await fetch(`${API_URL}/api/issues`, { method:'POST', headers:{ Authorization:`Bearer ${token()}`, 'Content-Type':'application/json' }, body: JSON.stringify(newIssue) });
      const d = await r.json();
      setIssues([{...d, ...newIssue}, ...issues]);
      setShowCreate(false);
      setNewIssue({ title:'', description:'', severity:'MEDIUM', priority:'MEDIUM', type:'CONTROL_GAP', owner:'' });
    } catch {} finally { setSubmitting(false); }
  };

  const addComment = async () => {
    if (!comment.trim() || !selected) return;
    setSubmitting(true);
    try {
      const r = await fetch(`${API_URL}/api/issues/${selected.id}/comments`, { method:'POST', headers:{ Authorization:`Bearer ${token()}`, 'Content-Type':'application/json' }, body: JSON.stringify({ text: comment }) });
      const d = await r.json();
      setSelected(s => ({ ...s, comments: [...(s.comments||[]), d] }));
      setComment('');
    } catch {} finally { setSubmitting(false); }
  };

  const updateStatus = async (id, status) => {
    try {
      await fetch(`${API_URL}/api/issues/${id}`, { method:'PATCH', headers:{ Authorization:`Bearer ${token()}`, 'Content-Type':'application/json' }, body: JSON.stringify({ status }) });
      setIssues(is => is.map(i => i.id===id ? {...i,status} : i));
      if (selected?.id===id) setSelected(s => ({...s,status}));
    } catch {}
  };

  return (
    <div className="page-content" data-testid="issue-management-page">
      <div className="page-header flex justify-between items-center">
        <div>
          <h1 className="page-title">Issue Management</h1>
          <p className="page-subtitle">Track, assign and resolve findings end-to-end</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowCreate(true)} data-testid="create-issue-button">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          New Issue
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="stat-grid" style={{ gridTemplateColumns:'repeat(auto-fit,minmax(140px,1fr))', marginBottom:24 }} data-testid="statistics-cards">
          <div className="stat-card"><div className="stat-label">Total</div><div className="stat-value">{stats.total}</div></div>
          {Object.entries(stats.by_status||{}).map(([k,v]) => (
            <div key={k} className="stat-card"><div className="stat-label">{k.replace('_',' ')}</div><div className="stat-value">{v}</div></div>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="filter-bar" data-testid="filter-dropdowns">
        <div className="filter-group">
          {[['','All Status'],['OPEN','Open'],['IN_PROGRESS','In Progress'],['RESOLVED','Resolved'],['CLOSED','Closed']].map(([v,l]) => (
            <button key={v} className={`filter-btn${filters.status===v?' active':''}`} onClick={() => setFilters(f=>({...f,status:v}))}>{l}</button>
          ))}
        </div>
        <div className="filter-group" data-testid="filter-priority">
          {[['','All Severity'],['CRITICAL','Critical'],['HIGH','High'],['MEDIUM','Medium'],['LOW','Low']].map(([v,l]) => (
            <button key={v} className={`filter-btn${filters.severity===v?' active':''}`} onClick={() => setFilters(f=>({...f,severity:v}))}>{l}</button>
          ))}
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns: selected ? '1fr 400px' : '1fr', gap:16, alignItems:'start' }}>
        {/* Issues list */}
        <div className="card" data-testid="issues-list">
          {loading ? (
            <div style={{ padding: '40px 0' }}>
              {[1,2,3].map(i=><div key={i} style={{padding:'18px 22px',borderBottom:'1px solid var(--border-subtle)'}}>
                <div className="skeleton skeleton-title" style={{width:'50%'}}/>
                <div className="skeleton skeleton-text" style={{width:'30%'}}/>
              </div>)}
            </div>
          ) : issues.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
              <div className="empty-title">No issues</div>
              <div className="empty-description">All clear — no issues match the current filters.</div>
            </div>
          ) : issues.map((issue, i) => (
            <div key={issue.id} data-testid={`issue-item-${i}`}
              onClick={() => setSelected(selected?.id===issue.id ? null : issue)}
              style={{ display:'flex', alignItems:'center', gap:14, padding:'15px 20px', borderBottom: i<issues.length-1?'1px solid var(--border-subtle)':'none', cursor:'pointer', background: selected?.id===issue.id?'var(--bg-raised)':'transparent', transition:'background var(--t-fast)' }}
              onMouseEnter={e => { if(selected?.id!==issue.id) e.currentTarget.style.background='var(--bg-raised)'; }}
              onMouseLeave={e => { if(selected?.id!==issue.id) e.currentTarget.style.background='transparent'; }}>
              <div style={{ width:3, height:36, borderRadius:2, background: SEV_COLOR[issue.severity] || 'var(--bg-elevated)', flexShrink:0 }} />
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:13,fontWeight:500,color:'var(--text-primary)',marginBottom:4,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{issue.title}</div>
                <div style={{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}}>
                  <Badge type="status"   val={issue.status}   />
                  <Badge type="severity" val={issue.severity} />
                  {issue.owner && <span style={{fontSize:11,color:'var(--text-tertiary)'}}>→ {issue.owner}</span>}
                  {issue.comments?.length > 0 && <span style={{fontSize:11,color:'var(--text-tertiary)'}}>{issue.comments.length} comment{issue.comments.length!==1?'s':''}</span>}
                </div>
              </div>
              <div style={{fontSize:11,color:'var(--text-tertiary)',flexShrink:0,textAlign:'right'}}>
                {issue.created_at ? new Date(issue.created_at).toLocaleDateString() : ''}
              </div>
            </div>
          ))}
        </div>

        {/* Detail panel */}
        {selected && (
          <div className="card" style={{position:'sticky',top:20}} data-testid="issue-detail-panel">
            <div className="card-header">
              <span style={{fontSize:13,fontWeight:600,color:'var(--text-primary)',flex:1,minWidth:0,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} data-testid="issue-title">{selected.title}</span>
              <button className="btn btn-ghost btn-sm btn-icon" onClick={() => setSelected(null)} data-testid="close-detail-panel">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div style={{padding:'16px 20px'}}>
              <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:16}}>
                <Badge type="status"   val={selected.status}   />
                <Badge type="severity" val={selected.severity} />
                {selected.priority && <span className="badge" style={{background:'var(--bg-elevated)',color:'var(--text-secondary)'}}>{selected.priority}</span>}
              </div>

              {selected.description && <p style={{fontSize:13,color:'var(--text-secondary)',lineHeight:1.6,marginBottom:16}}>{selected.description}</p>}

              <div style={{marginBottom:16}}>
                {[['Owner',selected.owner],['Type',selected.type],['Source',selected.source],['Business Unit',selected.business_unit],['Due',selected.due_date]].filter(([,v])=>v).map(([k,v])=>(
                  <div key={k} className="kv-row"><span className="kv-key">{k}</span><span className="kv-value">{v}</span></div>
                ))}
              </div>

              {/* Status update */}
              <div style={{marginBottom:16}}>
                <div className="panel-section-title">Update status</div>
                <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                  {['OPEN','IN_PROGRESS','RESOLVED','CLOSED'].map(s => (
                    <button key={s} className={`btn btn-sm${selected.status===s?' btn-secondary':' btn-outline'}`}
                      onClick={() => updateStatus(selected.id,s)} data-testid={`status-${s.toLowerCase()}`}>
                      {s.replace('_',' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Comments */}
              <div>
                <div className="panel-section-title">Comments ({(selected.comments||[]).length})</div>
                <div style={{marginBottom:12}}>
                  {(selected.comments||[]).map((c,i) => (
                    <div key={i} className="comment" data-testid={`comment-${i}`}>
                      <div className="comment-avatar">{initials(c.author)}</div>
                      <div style={{flex:1}}>
                        <div><span className="comment-author">{c.author}</span><span className="comment-time">{c.created_at ? new Date(c.created_at).toLocaleString() : ''}</span></div>
                        <div className="comment-text">{c.text}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{display:'flex',gap:8}}>
                  <input className="form-input" placeholder="Add a comment…" value={comment} onChange={e=>setComment(e.target.value)}
                    onKeyDown={e=>e.key==='Enter'&&!e.shiftKey&&addComment()} data-testid="comment-input" style={{flex:1}} />
                  <button className="btn btn-primary btn-sm" onClick={addComment} disabled={!comment.trim()||submitting} data-testid="submit-comment-button">Post</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Create modal */}
      {showCreate && (
        <div className="modal-overlay" data-testid="create-issue-form">
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">New Issue</span>
              <button className="modal-close" onClick={() => setShowCreate(false)}>×</button>
            </div>
            <form onSubmit={createIssue}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Title</label>
                  <input className="form-input" required value={newIssue.title} onChange={e=>setNewIssue(n=>({...n,title:e.target.value}))} placeholder="Describe the issue…" />
                </div>
                <div className="form-group">
                  <label className="form-label">Description</label>
                  <textarea className="form-input form-textarea" value={newIssue.description} onChange={e=>setNewIssue(n=>({...n,description:e.target.value}))} placeholder="Additional context…" />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Severity</label>
                    <select className="form-select" value={newIssue.severity} onChange={e=>setNewIssue(n=>({...n,severity:e.target.value}))}>
                      {['CRITICAL','HIGH','MEDIUM','LOW','INFO'].map(v=><option key={v}>{v}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Priority</label>
                    <select className="form-select" value={newIssue.priority} onChange={e=>setNewIssue(n=>({...n,priority:e.target.value}))}>
                      {['CRITICAL','HIGH','MEDIUM','LOW'].map(v=><option key={v}>{v}</option>)}
                    </select>
                  </div>
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Type</label>
                    <select className="form-select" value={newIssue.type} onChange={e=>setNewIssue(n=>({...n,type:e.target.value}))}>
                      {['CONTROL_GAP','RISK_FINDING','AUDIT_EXCEPTION','POLICY_VIOLATION','VULNERABILITY'].map(v=><option key={v}>{v.replace(/_/g,' ')}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Owner</label>
                    <input className="form-input" value={newIssue.owner} onChange={e=>setNewIssue(n=>({...n,owner:e.target.value}))} placeholder="Team or person…" />
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-ghost" onClick={()=>setShowCreate(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={!newIssue.title.trim()||submitting} data-testid="submit-issue-button">
                  {submitting ? 'Creating…' : 'Create Issue'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default IssueManagement;
