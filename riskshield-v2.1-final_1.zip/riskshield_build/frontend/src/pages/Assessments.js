import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '@/App';
import NewAssessmentModal from '@/components/NewAssessmentModal';

const statusBadge = (s) => {
  const map = { COMPLETED: 'completed', IN_PROGRESS: 'progress', FAILED: 'failed', DRAFT: 'draft', PENDING: 'pending' };
  return <span className={`badge badge-${map[s] || 'draft'}`}>{s?.replace('_',' ')}</span>;
};

const riskColor = (r) => ({ HIGH:'var(--color-critical)', MEDIUM:'var(--color-medium)', LOW:'var(--color-low)' }[r] || 'var(--text-tertiary)');

const Assessments = ({ user }) => {
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading]         = useState(true);
  const [showModal, setShowModal]     = useState(false);
  const [filter, setFilter]           = useState('all');

  useEffect(() => { loadAssessments(); }, []);

  useEffect(() => {
    const anyRunning = assessments.some(a => ['IN_PROGRESS','PENDING'].includes(a.status));
    if (!anyRunning) return;
    const t = setInterval(loadAssessments, 5000);
    return () => clearInterval(t);
  }, [assessments]);

  const loadAssessments = async () => {
    try {
      const r = await api.get('/assessments');
      setAssessments(r.data?.items || r.data || []);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const filtered = filter === 'all' ? assessments : assessments.filter(a => a.status === filter.toUpperCase().replace('-','_'));
  const anyRunning = assessments.some(a => ['IN_PROGRESS','PENDING'].includes(a.status));

  return (
    <div className="page-content" data-testid="assessments-page">
      <div className="page-header flex justify-between items-center">
        <div>
          <h1 className="page-title">Assessments</h1>
          <p className="page-subtitle">AI-orchestrated multi-framework technology risk assessments</p>
        </div>
        <div className="page-actions">
          {anyRunning && (
            <div className="ai-pulse">
              <span className="ai-pulse-dot" />
              AI agents running · auto-refreshing
            </div>
          )}
          <button className="btn btn-primary" onClick={() => setShowModal(true)} data-testid="new-assessment-button">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            New Assessment
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stat-grid" style={{ gridTemplateColumns: 'repeat(4,1fr)', marginBottom: 24 }}>
        {[
          ['Total', assessments.length],
          ['Completed', assessments.filter(a => a.status === 'COMPLETED').length],
          ['In Progress', assessments.filter(a => a.status === 'IN_PROGRESS').length],
          ['Failed', assessments.filter(a => a.status === 'FAILED').length],
        ].map(([l,v]) => (
          <div key={l} className="stat-card">
            <div className="stat-label">{l}</div>
            <div className="stat-value">{v}</div>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="filter-bar">
        <div className="filter-group">
          {[['all','All'],['completed','Completed'],['in-progress','In Progress'],['failed','Failed'],['draft','Draft']].map(([val,label]) => (
            <button key={val} className={`filter-btn${filter===val?' active':''}`} onClick={() => setFilter(val)}>{label}</button>
          ))}
        </div>
      </div>

      {/* List */}
      {loading ? (
        <div style={{ padding: '40px 0' }}>
          {[1,2,3].map(i => (
            <div key={i} style={{ display: 'flex', gap: 16, padding: '18px 22px', borderBottom: '1px solid var(--border-subtle)', alignItems: 'center' }}>
              <div className="skeleton skeleton-text" style={{ width: 36, height: 36, borderRadius: 8 }} />
              <div style={{ flex: 1 }}>
                <div className="skeleton skeleton-title" style={{ width: '40%' }} />
                <div className="skeleton skeleton-text" style={{ width: '25%' }} />
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
            </svg>
          </div>
          <div className="empty-title">No assessments yet</div>
          <div className="empty-description">Create your first AI-powered risk assessment to get started.</div>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>Create Assessment</button>
        </div>
      ) : (
        <div className="card">
          {filtered.map((a, i) => (
            <Link key={a.id} to={`/assessments/${a.id}`} data-testid={`assessment-item-${i}`}
              style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 22px', borderBottom: i < filtered.length-1 ? '1px solid var(--border-subtle)' : 'none', textDecoration: 'none', color: 'inherit', transition: 'background var(--t-fast)' }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-raised)'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
              {/* Status bar */}
              <div style={{ width: 3, height: 40, borderRadius: 2, flexShrink: 0, background: a.status === 'COMPLETED' ? 'var(--color-low)' : a.status === 'IN_PROGRESS' ? 'var(--color-info)' : a.status === 'FAILED' ? 'var(--color-critical)' : 'var(--bg-elevated)' }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                  <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-primary)', letterSpacing: '-0.01em' }}>{a.name}</span>
                  {statusBadge(a.status)}
                  {['IN_PROGRESS','PENDING'].includes(a.status) && <span className="ai-pulse" style={{ padding: '2px 8px', fontSize: 11 }}><span className="ai-pulse-dot" />running</span>}
                </div>
                <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                  {a.system_name && <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{a.system_name}</span>}
                  {a.business_unit && <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>· {a.business_unit}</span>}
                  {(a.frameworks || []).map(fw => <span key={fw} className="fw-pill">{fw}</span>)}
                </div>
              </div>
              {a.summary?.overall_risk && (
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-tertiary)', marginBottom: 2 }}>Risk</div>
                  <span style={{ fontSize: 13, fontWeight: 700, color: riskColor(a.summary.overall_risk) }}>{a.summary.overall_risk}</span>
                </div>
              )}
              <div style={{ flexShrink: 0 }}>
                <span style={{ display: 'flex', gap: 4, fontSize: 12, color: 'var(--text-tertiary)' }}>
                  <span>{(a.risks || []).length} risks</span>
                  <span>·</span>
                  <span>{(a.controls || []).length} controls</span>
                </span>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 2 }}>
                  {a.created_at ? new Date(a.created_at).toLocaleDateString() : ''}
                </div>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth="2">
                <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
              </svg>
            </Link>
          ))}
        </div>
      )}

      {showModal && <NewAssessmentModal onClose={() => setShowModal(false)} onCreated={(a) => { setAssessments([a,...assessments]); setShowModal(false); }} />}
    </div>
  );
};

export default Assessments;
