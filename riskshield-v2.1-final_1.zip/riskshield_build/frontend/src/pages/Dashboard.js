import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '@/App';

const statusColor = (s) => s === 'healthy' ? 'var(--color-low)' : s === 'warn' ? 'var(--color-medium)' : 'var(--color-critical)';

const TILES = [
  { id: 'control-analysis', to: '/control-analysis', accent: '#7f77dd',
    label: 'Register intelligence',
    title: 'Control Analysis',
    desc: 'Import registers via CSV, Excel or ServiceNow. AI quality scoring, duplicate detection, domain coverage, and real-time evidence evaluation.',
    cta: 'Open Control Analysis',
    icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg> },
  { id: 'regulatory-analysis', to: '/regulatory-analysis', accent: '#1d9e75',
    label: 'Obligation to control',
    title: 'Regulatory Analysis',
    desc: 'Upload regulation documents. AI extracts requirements, maps them to your controls, surfaces gaps, and enables one-click remediation.',
    cta: 'Open Regulatory Analysis',
    icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg> },
  { id: 'tech-risk', to: '/tech-risk-assessment', accent: '#f5ae3c',
    label: 'Application & tech risk',
    title: 'Risk Assessment',
    desc: 'AI-guided contextual questionnaires that adapt to system criticality. Automatic risk rating and professional PDF report generation.',
    cta: 'Open Risk Assessment',
    icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg> },
  { id: 'rcm-testing', to: '/rcm-testing', accent: '#5b8ff9',
    label: 'Guided RCM testing',
    title: 'Control Assurance',
    desc: 'Upload an RCM, let AI gap-check every test procedure, collect evidence with sufficiency ratings, and download PDF + Excel workpapers.',
    cta: 'Open RCM Testing',
    icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"><path d="M9 12l2 2 4-4"/><path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9"/></svg> },
  { id: 'issue-management', to: '/issue-management', accent: '#ff5c5c',
    label: 'Findings to closure',
    title: 'Issue Management',
    desc: 'Full case lifecycle with comment threads, SLA tracking, and ServiceNow sync. All findings linked to risks, controls and assessments.',
    cta: 'Open Issue Management',
    icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> },
];

const Dashboard = ({ user }) => {
  const [health, setHealth]   = useState(null);
  const [stats, setStats]     = useState(null);
  const firstName = (user?.full_name || '').split(' ')[0] || 'there';

  useEffect(() => {
    let alive = true;
    api.get('/system/health').then(r => { if (alive) setHealth(r.data); }).catch(() => {});
    api.get('/dashboard/stats').then(r => { if (alive) setStats(r.data); }).catch(() => {});
    return () => { alive = false; };
  }, []);

  const pillHref = (p) => {
    const l = (p.label || '').toLowerCase();
    if (l.includes('llm')) return '/admin';
    if (l.includes('servicenow')) return '/admin';
    return '/observability';
  };

  return (
    <div className="page-content" data-testid="command-center">

      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', letterSpacing: '0.09em', textTransform: 'uppercase', color: 'var(--text-tertiary)', marginBottom: 8 }}>
          RiskShield · Command Centre
        </div>
        <h1 style={{ fontSize: 28, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.025em', lineHeight: 1.1 }}>
          Good day, {firstName}.
        </h1>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 6, maxWidth: 560 }}>
          Select a workflow. Each module is self-contained and feeds into the shared risk, control and issue registers.
        </p>
      </div>

      {/* Stats row */}
      {stats && (
        <div className="stat-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(150px,1fr))' }}>
          {[
            ['Assessments', stats.total_assessments, stats.completed_assessments + ' completed'],
            ['Open Issues',  stats.open_issues,        stats.high_risk_items + ' high severity'],
            ['Controls',     stats.total_controls,      'in library'],
            ['AI Mode',      stats.llm_mode,           health?.llm_mode === 'LIVE' ? 'live inference' : 'mock responses'],
          ].map(([label, val, delta]) => (
            <div key={label} className="stat-card">
              <div className="stat-label">{label}</div>
              <div className="stat-value" style={{ fontSize: typeof val === 'string' ? 18 : 28 }}>{val}</div>
              <div className="stat-delta">{delta}</div>
            </div>
          ))}
        </div>
      )}

      {/* Health strip */}
      {health?.pills && (
        <div className="health-strip" data-testid="health-strip">
          {health.pills.map((p, i) => (
            <Link key={i} to={pillHref(p)} className="health-pill" data-testid={`health-pill-${i}`} title={p.detail}>
              <span className={`status-dot ${p.status === 'healthy' ? 'healthy' : p.status === 'warn' ? 'warn' : 'critical'}`} />
              <span style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{p.label}</span>
              <span style={{ color: 'var(--text-tertiary)', fontSize: 11 }}>{p.detail}</span>
            </Link>
          ))}
        </div>
      )}

      {/* Workflow Tiles */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px,1fr))', gap: 14 }} data-testid="tile-grid">
        {TILES.map(t => (
          <Link key={t.id} to={t.to} data-testid={`tile-${t.id}`}
            style={{
              display: 'flex', flexDirection: 'column', padding: '24px 26px',
              borderRadius: 'var(--radius-xl)',
              background: 'var(--bg-surface)',
              border: '1px solid var(--border-subtle)',
              textDecoration: 'none', color: 'inherit',
              minHeight: 230, position: 'relative', overflow: 'hidden',
              transition: 'border-color 0.2s, transform 0.15s, box-shadow 0.2s',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.borderColor = t.accent;
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = `0 12px 32px -10px ${t.accent}30`;
            }}
            onMouseLeave={e => {
              e.currentTarget.style.borderColor = 'var(--border-subtle)';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}>
            {/* Accent top bar */}
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: t.accent, opacity: 0.7 }} />

            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 18 }}>
              <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-md)', background: `${t.accent}18`, border: `1px solid ${t.accent}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: t.accent }}>
                {t.icon}
              </div>
              <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', textTransform: 'uppercase', color: t.accent, fontWeight: 600 }}>
                {t.label}
              </span>
            </div>

            <h2 style={{ fontSize: 17, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.01em', marginBottom: 10 }}>{t.title}</h2>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6, flex: 1 }}>{t.desc}</p>

            <div style={{ marginTop: 20, display: 'inline-flex', alignItems: 'center', gap: 7, fontSize: 13, fontWeight: 600, color: t.accent }}>
              {t.cta}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
              </svg>
            </div>
          </Link>
        ))}
      </div>

      {/* Footer hint */}
      <div style={{ marginTop: 40, fontSize: 11, color: 'var(--text-tertiary)', display: 'flex', alignItems: 'center', gap: 8 }}>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>
        </svg>
        Additional modules — Assessments, Knowledge Graph, Trend Analytics, Observability and Admin — are in the sidebar.
      </div>
    </div>
  );
};

export default Dashboard;
