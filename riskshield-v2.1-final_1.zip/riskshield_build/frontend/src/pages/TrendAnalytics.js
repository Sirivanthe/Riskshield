import { useState, useEffect } from 'react';
const API_URL = process.env.REACT_APP_BACKEND_URL;

const TrendAnalytics = ({ user }) => {
  const [trends, setTrends]   = useState([]);
  const [effect, setEffect]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = localStorage.getItem('token');
    const h = { Authorization: `Bearer ${t}` };
    Promise.all([
      fetch(`${API_URL}/api/v1/trends/risk-trends`, {headers:h}).then(r=>r.json()),
      fetch(`${API_URL}/api/v1/trends/control-effectiveness`, {headers:h}).then(r=>r.json()),
    ]).then(([tr, ef]) => {
      setTrends(tr.trends || []);
      setEffect(ef || []);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  const max = (key) => Math.max(...trends.map(t => t[key] || 0), 1);
  const barH = (val, key) => `${Math.round((val / max(key)) * 100)}%`;

  const EFF_COLOR = { EFFECTIVE:'var(--color-low)', PARTIALLY_EFFECTIVE:'var(--color-medium)', INEFFECTIVE:'var(--color-critical)', UNKNOWN:'var(--text-tertiary)' };

  if (loading) return (
    <div className="page-content">
      <div style={{display:'flex',gap:16,marginBottom:24}}>
        {[1,2,3,4].map(i=><div key={i} className="stat-card" style={{flex:1}}><div className="skeleton skeleton-title"/><div className="skeleton skeleton-text" style={{width:'40%'}}/></div>)}
      </div>
    </div>
  );

  const latest = trends[trends.length-1] || {};
  const prev   = trends[trends.length-2] || {};

  return (
    <div className="page-content">
      <div className="page-header">
        <h1 className="page-title">Trend Analytics</h1>
        <p className="page-subtitle">6-month risk and control effectiveness time series</p>
      </div>

      {/* KPI row */}
      <div className="stat-grid">
        {[
          ['High Risks', latest.high_risks, (latest.high_risks||0)-(prev.high_risks||0), true],
          ['Open Issues', latest.open_issues, (latest.open_issues||0)-(prev.open_issues||0), true],
          ['Controls Effective', `${latest.controls_effective||0}%`, (latest.controls_effective||0)-(prev.controls_effective||0), false],
          ['Total Risk Items', (latest.high_risks||0)+(latest.medium_risks||0)+(latest.low_risks||0), null, null],
        ].map(([l,v,delta,lower_is_better]) => (
          <div key={l} className="stat-card">
            <div className="stat-label">{l}</div>
            <div className="stat-value">{v}</div>
            {delta !== null && <div className={`stat-delta ${delta===0?'':lower_is_better?(delta<0?'up':'down'):(delta>0?'up':'down')}`}>
              {delta > 0 ? '↑' : delta < 0 ? '↓' : '—'} {Math.abs(delta||0)} vs last month
            </div>}
          </div>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:16 }}>
        {/* Risk trend chart */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Risk trend — 6 months</span>
            <div style={{display:'flex',gap:12,fontSize:11}}>
              {[['High','var(--color-critical)'],['Medium','var(--color-medium)'],['Low','var(--color-low)']].map(([l,c])=>(
                <span key={l} style={{display:'flex',alignItems:'center',gap:4,color:'var(--text-secondary)'}}>
                  <span style={{width:8,height:8,borderRadius:2,background:c,flexShrink:0}}/>
                  {l}
                </span>
              ))}
            </div>
          </div>
          <div style={{ padding:'24px 22px' }}>
            <div style={{ display:'flex', gap:8, alignItems:'flex-end', height:200 }}>
              {trends.map((t, i) => (
                <div key={i} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
                  <div style={{ width:'100%', display:'flex', gap:2, alignItems:'flex-end', height:170 }}>
                    {[['high_risks','var(--color-critical)'],['medium_risks','var(--color-medium)'],['low_risks','var(--color-low)']].map(([k,c])=>(
                      <div key={k} style={{ flex:1, background:c, borderRadius:'3px 3px 0 0', height: barH(t[k]||0, k), opacity:0.85, transition:'height 0.3s', minHeight: t[k]?4:0 }} title={`${k.replace('_risks','')} risks: ${t[k]||0}`} />
                    ))}
                  </div>
                  <div style={{ fontSize:10, color:'var(--text-tertiary)', fontFamily:'var(--font-mono)', whiteSpace:'nowrap' }}>{t.month?.slice(0,3)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Control effectiveness pie-style */}
        <div className="card">
          <div className="card-header"><span className="card-title">Control effectiveness</span></div>
          <div className="card-body">
            {effect.length === 0 ? (
              <div className="empty-state" style={{ padding:'24px 0' }}>
                <div className="empty-description">No control data</div>
              </div>
            ) : effect.map((e, i) => {
              const total = effect.reduce((s,x)=>s+x.count,0);
              const pct   = total ? Math.round(e.count/total*100) : 0;
              const color = EFF_COLOR[e.effectiveness] || 'var(--text-tertiary)';
              return (
                <div key={i} style={{ marginBottom:16 }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
                    <span style={{ fontSize:12, color:'var(--text-secondary)' }}>{e.effectiveness?.replace(/_/g,' ') || 'Unknown'}</span>
                    <span style={{ fontSize:12, fontFamily:'var(--font-mono)', color }}>{e.count} <span style={{color:'var(--text-tertiary)'}}>({pct}%)</span></span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width:`${pct}%`, background:color }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Monthly data table */}
      {trends.length > 0 && (
        <div className="card" style={{ marginTop:16 }}>
          <div className="card-header"><span className="card-title">Monthly detail</span></div>
          <div className="table-wrap" style={{ borderRadius:0, border:'none' }}>
            <table>
              <thead>
                <tr>
                  <th>Month</th>
                  <th>High risks</th>
                  <th>Medium risks</th>
                  <th>Low risks</th>
                  <th>Open issues</th>
                  <th>Controls effective</th>
                </tr>
              </thead>
              <tbody>
                {trends.map((t,i) => (
                  <tr key={i}>
                    <td style={{fontFamily:'var(--font-mono)',fontSize:12}}>{t.month}</td>
                    <td><span style={{color:'var(--color-critical)',fontWeight:600}}>{t.high_risks}</span></td>
                    <td><span style={{color:'var(--color-medium)'}}>{t.medium_risks}</span></td>
                    <td><span style={{color:'var(--color-low)'}}>{t.low_risks}</span></td>
                    <td>{t.open_issues}</td>
                    <td>
                      <div style={{display:'flex',alignItems:'center',gap:8}}>
                        <div className="progress-bar" style={{flex:1,maxWidth:80}}>
                          <div className="progress-fill low" style={{width:`${t.controls_effective||0}%`}}/>
                        </div>
                        <span style={{fontSize:11,fontFamily:'var(--font-mono)',color:'var(--text-secondary)'}}>{t.controls_effective}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default TrendAnalytics;
