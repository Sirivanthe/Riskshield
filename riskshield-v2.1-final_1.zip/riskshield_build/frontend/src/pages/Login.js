import { useState } from 'react';
import { api } from '@/App';

const Login = ({ onLogin }) => {
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const res = await api.post('/auth/login', { email, password });
      onLogin(res.data.access_token, res.data.user);
    } catch (err) {
      setError(err.response?.data?.detail || err.response?.data?.error?.message || 'Invalid credentials');
    } finally { setLoading(false); }
  };

  const fill = (role) => {
    const creds = { admin: ['admin@bank.com','admin123'], lod1: ['lod1@bank.com','password123'], lod2: ['lod2@bank.com','password123'] };
    setEmail(creds[role][0]); setPassword(creds[role][1]);
  };

  return (
    <div className="login-page" data-testid="login-page">

      {/* ── Left: Form ── */}
      <div className="login-form-side">
        <div className="login-card">
          <div className="login-logo">
            <div className="login-logo-icon">RS</div>
            <div>
              <div style={{ fontSize: '18px', fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>RiskShield</div>
              <div style={{ fontSize: '11px', color: 'var(--text-tertiary)', letterSpacing: '0.07em', textTransform: 'uppercase', marginTop: '2px' }}>Platform v2.1</div>
            </div>
          </div>

          <div className="login-heading">Sign in</div>
          <div className="login-subheading">Technology Risk &amp; Control Assurance</div>

          {error && (
            <div className="alert alert-error" data-testid="login-error">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0,marginTop:1}}>
                <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} data-testid="login-form">
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input type="email" className="form-input" value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@bank.com" required data-testid="login-email-input" />
            </div>

            <div className="form-group" style={{ marginBottom: 24 }}>
              <label className="form-label">Password</label>
              <input type="password" className="form-input" value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••" required data-testid="login-password-input" />
            </div>

            <button type="submit" className="btn btn-primary w-full btn-lg"
              disabled={loading} data-testid="login-submit-button"
              style={{ width: '100%', justifyContent: 'center', marginBottom: 20 }}>
              {loading ? (
                <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 14, height: 14, border: '2px solid rgba(9,13,20,0.3)', borderTopColor: 'var(--text-inverse)', borderRadius: '50%', animation: 'spin 0.75s linear infinite', display: 'inline-block' }} />
                  Signing in…
                </span>
              ) : 'Sign in'}
            </button>
          </form>

          <div style={{ fontSize: '11px', color: 'var(--text-tertiary)', marginBottom: '10px', letterSpacing: '0.05em', textTransform: 'uppercase', fontFamily: 'var(--font-mono)' }}>
            Demo access
          </div>
          <div className="login-demo-row">
            {[['admin','Admin','Full access'],['lod1','LOD1','Risk Owner'],['lod2','LOD2','Compliance']].map(([role,label,sub]) => (
              <button key={role} type="button" className="demo-pill"
                onClick={() => fill(role)} data-testid={`demo-${role}-button`}>
                {label}<span>{sub}</span>
              </button>
            ))}
          </div>

          <div style={{ marginTop: 36, fontSize: 11, color: 'var(--text-tertiary)', borderTop: '1px solid var(--border-subtle)', paddingTop: 20 }}>
            Secured with rate limiting, audit logging, and Fernet encryption.
          </div>
        </div>
      </div>

      {/* ── Right: Brand Panel ── */}
      <div className="login-panel">
        <div style={{ position: 'relative', zIndex: 1, maxWidth: 480 }}>
          <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 20 }}>
            Multi-Agent GRC Platform
          </div>
          <h2 style={{ fontSize: 40, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.03em', lineHeight: 1.1, marginBottom: 24 }}>
            Enterprise risk,<br />controlled by AI.
          </h2>
          <p style={{ fontSize: 15, color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: 40 }}>
            Real-time control assurance across NIST CSF, ISO 27001, SOC 2, RBI,
            and the EU AI Act — all orchestrated by multi-agent intelligence.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              ['Assessment Orchestrator', 'Async AI risk identification across all frameworks in parallel'],
              ['Control Analysis Engine', 'Import registers, score quality, evaluate evidence with 5W1H audit narratives'],
              ['Regulatory Gap Intelligence', 'Upload any regulation → requirements extracted → controls mapped → gaps surfaced'],
              ['Immutable Audit Log', 'Every event captured for regulators — RBI, FCA, SEC ready'],
            ].map(([title, desc]) => (
              <div key={title} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'var(--accent-dim)', border: '1px solid rgba(245,174,60,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 2 }}>
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2.5">
                    <polyline points="20 6 9 17 4 12"/>
                  </svg>
                </div>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 2 }}>{title}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-tertiary)', lineHeight: 1.5 }}>{desc}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 48, display: 'flex', gap: 24 }}>
            {[['18', 'UI modules'],['40+', 'API endpoints'],['7','LLM providers'],['6', 'Frameworks']].map(([n,l]) => (
              <div key={l}>
                <div style={{ fontSize: 22, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>{n}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 2 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
