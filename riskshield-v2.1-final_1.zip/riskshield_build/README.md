# 🛡️ RiskShield — AI-Powered Technology Risk & Control Platform

> Production-grade GRC platform for banking & financial institutions.  
> Multi-agent AI system for risk assessments, control testing, and regulatory compliance.

---

## What It Does

RiskShield automates the full GRC lifecycle using AI agents:

| Module | Description |
|---|---|
| **Risk Assessments** | AI-guided multi-framework assessments (NIST CSF, ISO 27001, SOC2, RBI, EU AI Act) |
| **Control Analysis** | Import registers via CSV/Excel/ServiceNow, AI quality scoring, duplicate detection |
| **Regulatory Analysis** | Upload regulation PDFs → AI extracts requirements → maps to controls → surfaces gaps |
| **RCM Testing Wizard** | Guided control testing with evidence collection and AI sufficiency rating |
| **Tech Risk Assessment** | Contextual questionnaires, AI risk scoring, PDF report generation |
| **Issue Management** | End-to-end findings tracking, comments, SLA, ServiceNow sync |
| **Trend Analytics** | Time-series risk and control effectiveness dashboards |
| **Knowledge Graph** | Visual map of controls, domains, and relationships |
| **Observability** | LLM call tracking, cost estimation, agent activity log |

---

## Quick Start (Local — No Install Needed)

```bash
# 1. Setup (generates encryption keys, creates .env)
bash scripts/setup.sh

# 2. (Optional) Add your Anthropic API key for real AI
echo "ANTHROPIC_API_KEY=sk-ant-..." >> backend/.env

# 3. Start
bash scripts/start.sh

# 4. Open browser
open http://localhost:3000
```

**Default credentials:**
| Role | Email | Password |
|---|---|---|
| Admin | admin@bank.com | admin123 |
| LOD1 (Risk Owner) | lod1@bank.com | password123 |
| LOD2 (Compliance) | lod2@bank.com | password123 |

> **MOCK mode:** Platform runs fully functional without any API key, using intelligent mock responses. Add `ANTHROPIC_API_KEY` to switch to real Claude AI.

---

## Production Deployment

```bash
# Docker Compose
cp backend/.env.example backend/.env
# Edit backend/.env with your values
docker-compose -f deploy/docker-compose.yml up -d
```

Or Kubernetes — see `deploy/k8s-*.yaml`.

---

## Architecture

```
riskshield/
├── backend/
│   ├── local_server.py        ← Local dev server (Flask + SQLite)
│   ├── server.py              ← Production server (FastAPI + MongoDB)
│   ├── agents/                ← Multi-agent AI orchestration
│   ├── routes/                ← Modular API route handlers
│   ├── services/
│   │   ├── llm_client.py      ← Direct Anthropic/OpenAI/Gemini SDKs
│   │   ├── llm_evaluator.py   ← Evidence evaluation, 5W1H, control uplift
│   │   ├── audit_log.py       ← Immutable audit trail (banking compliance)
│   │   ├── rate_limiter.py    ← Token bucket rate limiting
│   │   ├── input_validation.py← Prompt injection defence
│   │   ├── control_history.py ← Control version history
│   │   ├── job_queue.py       ← Persistent async job queue
│   │   ├── fernet_rotation.py ← Encryption key rotation utility
│   │   ├── encryption.py      ← At-rest Fernet encryption
│   │   ├── vector_store.py    ← FAISS RAG vector store
│   │   └── pdf_report_generator.py
│   └── tests/                 ← pytest test suite
├── frontend/
│   └── src/pages/             ← 18 React pages (Shadcn UI)
├── deploy/
│   ├── docker-compose.yml
│   ├── Dockerfile.backend
│   ├── Dockerfile.frontend
│   └── k8s-*.yaml
└── scripts/
    ├── setup.sh
    ├── start.sh
    ├── stop.sh
    └── rotate-key.sh
```

---

## LLM Providers

Configure in Admin → LLM Configuration or set env vars:

| Provider | Env Var | Default Model |
|---|---|---|
| Anthropic Claude | `ANTHROPIC_API_KEY` | claude-sonnet-4-5 |
| OpenAI | `OPENAI_API_KEY` | gpt-4o |
| Google Gemini | `GOOGLE_API_KEY` | gemini-2.5-pro |
| Ollama (local) | `OLLAMA_HOST` | llama3 |
| Azure OpenAI | `AZURE_AI_ENDPOINT` | configurable |
| Mock (demo) | — | — |

---

## Security Features (v2.1)

- **Rate limiting** — 10 auth attempts/min per IP, 300 API req/min
- **Prompt injection defence** — pattern matching on all user-supplied text before LLM calls
- **Immutable audit log** — every auth, data mutation and LLM call logged
- **At-rest encryption** — Fernet (AES-128-CBC + HMAC-SHA256) for API keys and credentials
- **Key rotation** — `bash scripts/rotate-key.sh` with dry-run support
- **Control version history** — full audit trail of every control change
- **Role-based access** — LOD1 / LOD2 / Admin with granular permission enforcement
- **Structured errors** — `{"error": {"code": "...", "message": "..."}}` never leaks internals
- **Security headers** — X-Frame-Options, X-Content-Type-Options on all responses

---

## API Reference

Base URL: `http://localhost:8001/api`

All endpoints (except `/`, `/system/health`) require `Authorization: Bearer <token>`.

**Auth**
- `POST /auth/login` — Get JWT token
- `GET /auth/me` — Current user
- `POST /auth/logout` — Logout (audit logged)
- `POST /auth/change-password` — Change password

**Assessments**
- `GET /assessments?page=1&limit=20` — List (paginated)
- `POST /assessments` — Create (async AI analysis)
- `GET /assessments/:id` — Detail

**Controls**
- `GET /control-analysis/controls?page=1` — List
- `POST /control-analysis/controls` — Create
- `PATCH /control-analysis/controls/:id` — Update
- `DELETE /control-analysis/controls/:id` — Delete (LOD2+ only)
- `GET /control-analysis/controls/:id/history` — Version history

**Issues**
- `GET /issues?status=OPEN&severity=HIGH&page=1` — Filtered list
- `POST /issues` — Create
- `PATCH /issues/:id` — Update
- `POST /issues/:id/comments` — Add comment
- `GET /issues/stats` — Statistics

**Tech Risk, Trends, Observability, Admin** — see full API docs at `/docs`

---

## Environment Variables

See `backend/.env.example` for full reference.

**Critical:**
- `RISKSHIELD_ENCRYPTION_KEY` — Generate once, never change: `bash scripts/rotate-key.sh --generate`
- `JWT_SECRET` — Long random secret for JWT signing

---

## Roadmap

- [ ] SSO/SAML integration (required for bank production)
- [ ] Evidence file upload to S3/Azure Blob
- [ ] What-if risk simulations
- [ ] WebSocket real-time dashboard updates
- [ ] Celery + Redis job queue (horizontal scaling)
- [ ] Real-time collaboration
- [ ] Mobile app

---

*Built on Python 3.12 · Flask/FastAPI · MongoDB/SQLite · React 18 · Shadcn UI*
