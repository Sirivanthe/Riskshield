# LLM Evaluator Service
# Real LLM-powered evaluation via Anthropic Claude (direct SDK).
#
# Provides async helpers for:
#   - evaluate_evidence(): check whether uploaded evidence validates a control
#   - generate_5w1h(): produce a 5W1H audit report for a control+evidence pair
#   - uplift_control_language(): rewrite a control description/test procedure
#   - analyze_test_procedure(): assess adequacy of a test procedure
#   - extract_controls_from_text(): extract structured controls from unstructured text

import os
import json
import logging
import asyncio
import re
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "claude-sonnet-4-5-20250929"


def _get_api_key() -> str:
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise RuntimeError("ANTHROPIC_API_KEY is not configured in backend/.env")
    return key


def _extract_json(text: str) -> Dict[str, Any]:
    """Best-effort JSON extraction from an LLM response."""
    if not text:
        return {}
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    candidate = fenced.group(1) if fenced else text
    start = candidate.find("{")
    end = candidate.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return {"raw": text}
    try:
        return json.loads(candidate[start:end + 1])
    except json.JSONDecodeError:
        logger.warning("Failed to parse LLM JSON response; returning raw text")
        return {"raw": text}


async def _call_claude(system_message: str, user_message: str) -> str:
    """Call Claude API asynchronously using run_in_executor to avoid blocking."""
    import anthropic
    
    def _sync_call():
        client = anthropic.Anthropic(api_key=_get_api_key())
        message = client.messages.create(
            model=DEFAULT_MODEL,
            max_tokens=4096,
            system=system_message,
            messages=[{"role": "user", "content": user_message}],
        )
        return message.content[0].text if message.content else ""
    
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _sync_call)


async def evaluate_evidence(
    control: Dict[str, Any],
    evidence_text: str,
    test_script: Optional[str] = None,
) -> Dict[str, Any]:
    """Evaluate whether evidence validates a control against its test script."""
    system_message = (
        "You are a senior technology risk and audit expert. Evaluate whether the provided "
        "evidence adequately demonstrates that the stated control is operating effectively. "
        "Be rigorous but fair. Respond ONLY with valid JSON."
    )
    prompt = f"""Control: {control.get('name', '')}
Description: {control.get('description', '')}
Test Script: {test_script or control.get('test_procedure', '(none provided)')}

Evidence:
\"\"\"
{evidence_text[:8000]}
\"\"\"

Respond with JSON in EXACTLY this schema:
{{
  "status": "PASS" | "FAIL" | "PARTIAL",
  "score": 0-100,
  "reasoning": "2-3 sentence justification",
  "gaps": ["specific gap 1", "gap 2"],
  "recommendations": ["recommendation 1", "recommendation 2"]
}}"""
    try:
        response = await _call_claude(system_message, prompt)
        result = _extract_json(response)
        result.setdefault("status", "FAIL")
        result.setdefault("score", 0)
        result.setdefault("reasoning", "")
        result.setdefault("gaps", [])
        result.setdefault("recommendations", [])
        return result
    except Exception as e:
        logger.error(f"evaluate_evidence failed: {e}")
        return {"status": "FAIL", "score": 0, "reasoning": str(e), "gaps": [], "recommendations": [], "error": str(e)}


async def generate_5w1h(control: Dict[str, Any], evidence_text: str) -> Dict[str, Any]:
    """Generate a 5W1H audit narrative for a control+evidence pair."""
    system_message = (
        "You are an expert audit narrator. Generate a structured 5W1H (Who, What, When, "
        "Where, Why, How) audit narrative for this control and evidence. Be precise and concise. "
        "Respond ONLY with valid JSON."
    )
    prompt = f"""Control: {control.get('name', '')}
Description: {control.get('description', '')}

Evidence:
\"\"\"
{evidence_text[:6000]}
\"\"\"

Respond with JSON:
{{
  "who": "who performs or owns the control",
  "what": "what the control does",
  "when": "when/how frequently the control operates",
  "where": "where the control operates (systems, locations)",
  "why": "why this control is necessary (risk addressed)",
  "how": "how the control is implemented and tested"
}}"""
    try:
        response = await _call_claude(system_message, prompt)
        result = _extract_json(response)
        for key in ["who", "what", "when", "where", "why", "how"]:
            result.setdefault(key, "")
        return result
    except Exception as e:
        logger.error(f"generate_5w1h failed: {e}")
        return {k: "" for k in ["who", "what", "when", "where", "why", "how"]}


async def uplift_control_language(control: Dict[str, Any]) -> Dict[str, Any]:
    """Rewrite control description and test procedure into precise auditable language."""
    system_message = (
        "You are an expert GRC control writer. Rewrite control descriptions and test procedures "
        "into precise, mandatory-language, auditable statements. Respond ONLY with valid JSON."
    )
    prompt = f"""Control Name: {control.get('name', '')}
Current Description: {control.get('description', '')}
Current Test Procedure: {control.get('test_procedure', '(none provided)')}

Respond with JSON:
{{
  "improved_description": "rewritten description in mandatory language (shall/must)",
  "improved_test_procedure": "rewritten step-by-step verifiable test procedure",
  "quality_improvements": ["improvement 1", "improvement 2"]
}}"""
    try:
        response = await _call_claude(system_message, prompt)
        result = _extract_json(response)
        result.setdefault("improved_description", control.get("description", ""))
        result.setdefault("improved_test_procedure", control.get("test_procedure", ""))
        result.setdefault("quality_improvements", [])
        return result
    except Exception as e:
        logger.error(f"uplift_control_language failed: {e}")
        return {"improved_description": control.get("description", ""), "improved_test_procedure": control.get("test_procedure", ""), "quality_improvements": []}


async def analyze_test_procedure(control: Dict[str, Any]) -> Dict[str, Any]:
    """Assess the adequacy of a control's test procedure."""
    system_message = (
        "You are a senior audit expert. Assess the adequacy of a control test procedure. "
        "Respond ONLY with valid JSON."
    )
    prompt = f"""Control: {control.get('name', '')}
Description: {control.get('description', '')}
Current Test Procedure: {control.get('test_procedure', '(none provided)')}

Respond with JSON:
{{
  "adequacy_score": 0-100,
  "adequate": true | false,
  "gaps": ["specific gap 1"],
  "evidence_requirements": [{{"item": "what to obtain", "why": "why it matters", "type": "screenshot|log|report|policy|config|other"}}],
  "suggested_improvement": "rewritten test procedure",
  "reasoning": "2-3 sentence justification"
}}"""
    try:
        response = await _call_claude(system_message, prompt)
        result = _extract_json(response)
        result.setdefault("adequacy_score", 0)
        result.setdefault("adequate", False)
        result.setdefault("gaps", [])
        result.setdefault("evidence_requirements", [])
        result.setdefault("suggested_improvement", control.get("test_procedure", ""))
        result.setdefault("reasoning", "")
        return result
    except Exception as e:
        logger.error(f"analyze_test_procedure failed: {e}")
        return {"adequacy_score": 0, "adequate": False, "gaps": [str(e)], "evidence_requirements": [], "suggested_improvement": "", "reasoning": "", "error": str(e)}


async def extract_controls_from_text(text: str, source_hint: str = "") -> Dict[str, Any]:
    """Extract structured controls from unstructured text (PDF, regulation doc, etc.)."""
    system_message = (
        "You are an expert technology risk analyst. Extract distinct internal controls "
        "from the provided text. Be precise. Deduplicate. If a section describes a risk, "
        "infer the matching preventive/detective control. Respond ONLY with valid JSON."
    )
    prompt = f"""Extract controls from this text.
Source hint: {source_hint or 'PDF / unstructured document'}

TEXT:
\"\"\"
{text[:15000]}
\"\"\"

Return JSON:
{{
  "controls": [
    {{
      "control_id": "CTRL-### or document-derived id",
      "name": "<=80 char control name",
      "description": "mandatory-language description",
      "domain": "Access Control | Data Protection | Vendor Risk | Incident Mgmt | Change Mgmt | Third Party | Business Continuity | AI Governance | Other",
      "owner": "role or function responsible (else empty string)",
      "type": "TECHNICAL | ADMINISTRATIVE | PHYSICAL",
      "category": "PREVENTIVE | DETECTIVE | CORRECTIVE",
      "test_procedure": "verifiable step-by-step test procedure",
      "frameworks": ["list of regulations/frameworks"]
    }}
  ]
}}"""
    try:
        response = await _call_claude(system_message, prompt)
        result = _extract_json(response)
        controls = result.get("controls") or []
        cleaned = []
        for i, c in enumerate(controls[:200], start=1):
            cleaned.append({
                "control_id": c.get("control_id") or f"CTRL-PDF-{i:03d}",
                "name": c.get("name", "")[:200],
                "description": c.get("description", ""),
                "domain": c.get("domain", "Other"),
                "owner": c.get("owner", ""),
                "type": c.get("type", "ADMINISTRATIVE"),
                "category": c.get("category", "PREVENTIVE"),
                "test_procedure": c.get("test_procedure", ""),
                "frameworks": c.get("frameworks", []) or [],
            })
        return {"controls": cleaned}
    except Exception as e:
        logger.error(f"extract_controls_from_text failed: {e}")
        return {"controls": [], "error": str(e)}
