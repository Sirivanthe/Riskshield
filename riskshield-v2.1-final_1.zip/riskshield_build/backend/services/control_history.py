"""
Control Version History Service
Tracks every change to a control record — required by auditors.
"""
import uuid
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


async def record_control_change(
    db,
    control_id: str,
    changed_by_id: str,
    changed_by_email: str,
    change_type: str,       # "CREATE" | "UPDATE" | "DELETE" | "TEST"
    before: Optional[Dict[str, Any]],
    after: Optional[Dict[str, Any]],
    notes: str = "",
) -> str:
    """Write a version history record for a control."""
    record_id = str(uuid.uuid4())
    fields_changed = []
    if before and after:
        for k in set(list(before.keys()) + list(after.keys())):
            if before.get(k) != after.get(k):
                fields_changed.append(k)

    record = {
        "_id": record_id,
        "control_id": control_id,
        "change_type": change_type,
        "changed_by_id": changed_by_id,
        "changed_by_email": changed_by_email,
        "fields_changed": fields_changed,
        "before": before,
        "after": after,
        "notes": notes,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    try:
        await db.control_history.insert_one(record)
    except Exception as e:
        logger.error(f"Control history write failed: {e}")
    return record_id


async def get_control_history(db, control_id: str, limit: int = 50) -> List[Dict]:
    """Get version history for a specific control."""
    cursor = db.control_history.find(
        {"control_id": control_id}, {"_id": 0}
    ).sort("timestamp", -1).limit(limit)
    return await cursor.to_list(length=limit)
