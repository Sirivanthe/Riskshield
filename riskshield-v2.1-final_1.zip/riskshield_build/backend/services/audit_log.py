"""
Immutable Audit Log Service
Every LLM call, data mutation, and auth event is written here.
Required for banking regulators (RBI, FCA, SEC etc.)
"""
import uuid
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class AuditLogger:
    """Writes audit events to MongoDB audit_log collection."""

    CATEGORIES = {
        "AUTH":       "Authentication events",
        "DATA":       "Data create/read/update/delete",
        "LLM":        "AI/LLM calls and responses",
        "ADMIN":      "Administrative actions",
        "EXPORT":     "Data exports and downloads",
        "SECURITY":   "Security events (rate limit, bad token, etc.)",
        "SYSTEM":     "System events",
    }

    def __init__(self, db):
        self.db = db

    async def log(
        self,
        category: str,
        action: str,
        actor_id: Optional[str],
        actor_email: Optional[str],
        resource_type: str,
        resource_id: Optional[str],
        details: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None,
        success: bool = True,
    ) -> str:
        """Write an immutable audit event. Returns the event ID."""
        event_id = str(uuid.uuid4())
        event = {
            "_id": event_id,
            "category": category,
            "action": action,
            "actor_id": actor_id,
            "actor_email": actor_email,
            "resource_type": resource_type,
            "resource_id": resource_id,
            "details": details or {},
            "ip_address": ip_address,
            "success": success,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        try:
            await self.db.audit_log.insert_one(event)
        except Exception as e:
            # Never let audit logging break the main request
            logger.error(f"Audit log write failed: {e}")
        return event_id

    async def get_events(
        self,
        category: Optional[str] = None,
        actor_email: Optional[str] = None,
        resource_type: Optional[str] = None,
        limit: int = 100,
        skip: int = 0,
    ):
        """Query audit events with optional filters."""
        query: Dict[str, Any] = {}
        if category:
            query["category"] = category
        if actor_email:
            query["actor_email"] = actor_email
        if resource_type:
            query["resource_type"] = resource_type

        cursor = self.db.audit_log.find(
            query, {"_id": 0}
        ).sort("timestamp", -1).skip(skip).limit(limit)
        return await cursor.to_list(length=limit)


_audit: Optional[AuditLogger] = None


def get_audit_logger(db=None) -> AuditLogger:
    """Get or create the global audit logger."""
    global _audit
    if _audit is None and db is not None:
        _audit = AuditLogger(db)
    return _audit
