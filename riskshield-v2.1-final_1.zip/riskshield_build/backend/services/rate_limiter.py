"""
Rate Limiter — token bucket per IP for auth endpoints.
No external deps required (stdlib only).
"""
import time
import threading
from collections import defaultdict
from typing import Dict, Tuple

class RateLimiter:
    """
    Simple in-process token bucket rate limiter.
    For production, replace with Redis-backed implementation.
    """

    def __init__(self, max_calls: int = 10, period_seconds: float = 60.0):
        self.max_calls = max_calls
        self.period = period_seconds
        self._buckets: Dict[str, Tuple[int, float]] = defaultdict(lambda: (max_calls, time.monotonic()))
        self._lock = threading.Lock()

    def is_allowed(self, key: str) -> bool:
        """Return True if the request is allowed, False if rate-limited."""
        now = time.monotonic()
        with self._lock:
            calls, window_start = self._buckets[key]
            elapsed = now - window_start
            if elapsed >= self.period:
                # Reset window
                self._buckets[key] = (self.max_calls - 1, now)
                return True
            if calls > 0:
                self._buckets[key] = (calls - 1, window_start)
                return True
            return False

    def reset(self, key: str) -> None:
        """Reset bucket for a key (e.g. after successful login)."""
        with self._lock:
            if key in self._buckets:
                del self._buckets[key]


# Global rate limiters
auth_limiter = RateLimiter(max_calls=10, period_seconds=60)     # 10 attempts/min per IP
api_limiter  = RateLimiter(max_calls=300, period_seconds=60)    # 300 req/min per IP
