# Multi-provider LLM Client - Direct SDK integrations (no third-party wrappers)
import os
import json
import logging
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone

from models import LLMProvider, LLMConfig

logger = logging.getLogger(__name__)


class BaseLLMClient(ABC):
    """Abstract base class for LLM clients"""

    @abstractmethod
    async def generate(self, prompt: str, context: str = "", system_prompt: str = "") -> Dict[str, Any]:
        """Generate a response from the LLM

        Returns:
            Dict with keys: 'response', 'prompt_tokens', 'completion_tokens', 'model_name'
        """
        pass

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if the LLM service is available"""
        pass


class AnthropicLLMClient(BaseLLMClient):
    """Direct Anthropic Claude client via official SDK"""

    DEFAULT_MODEL = "claude-sonnet-4-5-20250929"

    def __init__(self, config: LLMConfig):
        self.config = config
        self.model_name = config.model_name or self.DEFAULT_MODEL
        self.api_key = config.api_key or os.environ.get("ANTHROPIC_API_KEY", "")

    async def generate(self, prompt: str, context: str = "", system_prompt: str = "") -> Dict[str, Any]:
        import anthropic
        client = anthropic.Anthropic(api_key=self.api_key)
        sys_msg = system_prompt or "You are a helpful assistant."
        user_text = f"Context:\n{context}\n\nRequest:\n{prompt}" if context else prompt

        message = client.messages.create(
            model=self.model_name,
            max_tokens=self.config.max_tokens or 4096,
            system=sys_msg,
            messages=[{"role": "user", "content": user_text}],
        )
        response_text = message.content[0].text if message.content else ""
        return {
            "response": response_text,
            "prompt_tokens": message.usage.input_tokens,
            "completion_tokens": message.usage.output_tokens,
            "model_name": self.model_name,
        }

    async def health_check(self) -> bool:
        return bool(self.api_key)


class OpenAILLMClient(BaseLLMClient):
    """Direct OpenAI client via official SDK"""

    DEFAULT_MODEL = "gpt-4o"

    def __init__(self, config: LLMConfig):
        self.config = config
        self.model_name = config.model_name or self.DEFAULT_MODEL
        self.api_key = config.api_key or os.environ.get("OPENAI_API_KEY", "")

    async def generate(self, prompt: str, context: str = "", system_prompt: str = "") -> Dict[str, Any]:
        from openai import OpenAI
        client = OpenAI(api_key=self.api_key)
        sys_msg = system_prompt or "You are a helpful assistant."
        user_text = f"Context:\n{context}\n\nRequest:\n{prompt}" if context else prompt

        resp = client.chat.completions.create(
            model=self.model_name,
            max_tokens=self.config.max_tokens or 4096,
            messages=[
                {"role": "system", "content": sys_msg},
                {"role": "user", "content": user_text},
            ],
            temperature=self.config.temperature or 0.2,
        )
        response_text = resp.choices[0].message.content or ""
        return {
            "response": response_text,
            "prompt_tokens": resp.usage.prompt_tokens,
            "completion_tokens": resp.usage.completion_tokens,
            "model_name": self.model_name,
        }

    async def health_check(self) -> bool:
        return bool(self.api_key)


class GeminiLLMClient(BaseLLMClient):
    """Direct Google Gemini client via official SDK"""

    DEFAULT_MODEL = "gemini-2.5-pro"

    def __init__(self, config: LLMConfig):
        self.config = config
        self.model_name = config.model_name or self.DEFAULT_MODEL
        self.api_key = config.api_key or os.environ.get("GOOGLE_API_KEY", "")

    async def generate(self, prompt: str, context: str = "", system_prompt: str = "") -> Dict[str, Any]:
        import google.generativeai as genai
        genai.configure(api_key=self.api_key)
        model = genai.GenerativeModel(
            self.model_name,
            system_instruction=system_prompt or "You are a helpful assistant.",
        )
        user_text = f"Context:\n{context}\n\nRequest:\n{prompt}" if context else prompt
        response = model.generate_content(
            user_text,
            generation_config={"temperature": self.config.temperature or 0.2, "max_output_tokens": self.config.max_tokens or 4096},
        )
        response_text = response.text if hasattr(response, "text") else ""
        usage = getattr(response, "usage_metadata", None)
        return {
            "response": response_text,
            "prompt_tokens": usage.prompt_token_count if usage else len(user_text.split()),
            "completion_tokens": usage.candidates_token_count if usage else len(response_text.split()),
            "model_name": self.model_name,
        }

    async def health_check(self) -> bool:
        return bool(self.api_key)


class MockLLMClient(BaseLLMClient):
    """Mock LLM client for local testing without API keys"""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.model_name = config.model_name or "mock-llm"

    async def generate(self, prompt: str, context: str = "", system_prompt: str = "") -> Dict[str, Any]:
        response = ""
        if "risk" in prompt.lower():
            response = json.dumps({
                "risks": [
                    {"title": "Insufficient Access Controls", "severity": "HIGH", "framework": "NIST CSF"},
                    {"title": "Weak Encryption Standards", "severity": "MEDIUM", "framework": "ISO 27001"},
                    {"title": "Inadequate Audit Logging", "severity": "MEDIUM", "framework": "SOC2"},
                ]
            })
        elif "control" in prompt.lower():
            response = json.dumps({
                "controls": [
                    {"name": "IAM Policy Review", "effectiveness": "EFFECTIVE"},
                    {"name": "Encryption at Rest", "effectiveness": "PARTIALLY_EFFECTIVE"},
                    {"name": "Log Monitoring", "effectiveness": "INEFFECTIVE"},
                ]
            })
        else:
            response = json.dumps({"message": "Mock response generated"})
        return {
            "response": response,
            "prompt_tokens": len(prompt.split()),
            "completion_tokens": len(response.split()),
            "model_name": self.model_name,
        }

    async def health_check(self) -> bool:
        return True


class OllamaLLMClient(BaseLLMClient):
    """Ollama local LLM client"""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.model_name = config.model_name or "llama3"
        self.host = config.ollama_host or os.environ.get("OLLAMA_HOST", "http://localhost:11434")

    async def generate(self, prompt: str, context: str = "", system_prompt: str = "") -> Dict[str, Any]:
        import httpx
        full_prompt = f"{system_prompt}\n\nContext:\n{context}\n\nUser:\n{prompt}" if context else f"{system_prompt}\n\n{prompt}"
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{self.host}/api/generate",
                json={"model": self.model_name, "prompt": full_prompt, "stream": False,
                      "options": {"temperature": self.config.temperature, "num_predict": self.config.max_tokens}},
            )
            response.raise_for_status()
            data = response.json()
            return {
                "response": data.get("response", ""),
                "prompt_tokens": data.get("prompt_eval_count", len(prompt.split())),
                "completion_tokens": data.get("eval_count", len(data.get("response", "").split())),
                "model_name": self.model_name,
            }

    async def health_check(self) -> bool:
        import httpx
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(f"{self.host}/api/tags")
                return response.status_code == 200
        except Exception:
            return False


class AzureLLMClient(BaseLLMClient):
    """Azure OpenAI client"""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.endpoint = config.azure_endpoint or os.environ.get("AZURE_AI_ENDPOINT")
        self.deployment = config.azure_deployment or os.environ.get("AZURE_AI_DEPLOYMENT")
        self.model_name = config.model_name or "gpt-4"
        self.api_key = os.environ.get("AZURE_OPENAI_API_KEY", "")

    async def generate(self, prompt: str, context: str = "", system_prompt: str = "") -> Dict[str, Any]:
        import httpx
        api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01")
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        if context:
            messages.append({"role": "user", "content": f"Context:\n{context}"})
        messages.append({"role": "user", "content": prompt})
        url = f"{self.endpoint}/openai/deployments/{self.deployment}/chat/completions?api-version={api_version}"
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                url, headers={"api-key": self.api_key, "Content-Type": "application/json"},
                json={"messages": messages, "temperature": self.config.temperature, "max_tokens": self.config.max_tokens},
            )
            response.raise_for_status()
            data = response.json()
            return {
                "response": data["choices"][0]["message"]["content"],
                "prompt_tokens": data["usage"]["prompt_tokens"],
                "completion_tokens": data["usage"]["completion_tokens"],
                "model_name": self.deployment or self.model_name,
            }

    async def health_check(self) -> bool:
        return bool(self.api_key and self.endpoint)


class VertexAILLMClient(BaseLLMClient):
    """Google Vertex AI client"""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.project = config.vertex_project or os.environ.get("GOOGLE_CLOUD_PROJECT")
        self.location = config.vertex_location or os.environ.get("GOOGLE_CLOUD_LOCATION", "us-central1")
        self.model_name = config.model_name or "gemini-1.5-pro"
        self.api_key = os.environ.get("GOOGLE_API_KEY", "")

    async def generate(self, prompt: str, context: str = "", system_prompt: str = "") -> Dict[str, Any]:
        import httpx
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model_name}:generateContent?key={self.api_key}"
        full_prompt = ""
        if system_prompt:
            full_prompt += f"Instructions: {system_prompt}\n\n"
        if context:
            full_prompt += f"Context:\n{context}\n\n"
        full_prompt += f"Request:\n{prompt}"
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                url, json={"contents": [{"parts": [{"text": full_prompt}]}],
                           "generationConfig": {"temperature": self.config.temperature, "maxOutputTokens": self.config.max_tokens}},
            )
            response.raise_for_status()
            data = response.json()
            response_text = data["candidates"][0]["content"]["parts"][0]["text"]
            usage = data.get("usageMetadata", {})
            return {
                "response": response_text,
                "prompt_tokens": usage.get("promptTokenCount", len(prompt.split())),
                "completion_tokens": usage.get("candidatesTokenCount", len(response_text.split())),
                "model_name": self.model_name,
            }

    async def health_check(self) -> bool:
        return bool(self.api_key)


class LLMClientFactory:
    """Factory for creating LLM clients based on configuration"""

    _clients: Dict[str, BaseLLMClient] = {}
    _current_config: Optional[LLMConfig] = None

    @classmethod
    def get_client(cls, config: Optional[LLMConfig] = None) -> BaseLLMClient:
        if config is None:
            config = cls._current_config or LLMConfig()
        cls._current_config = config
        client_key = f"{config.provider}_{config.model_name}"
        if client_key not in cls._clients:
            cls._clients[client_key] = cls._create_client(config)
        return cls._clients[client_key]

    @classmethod
    def _create_client(cls, config: LLMConfig) -> BaseLLMClient:
        if config.provider == LLMProvider.ANTHROPIC:
            return AnthropicLLMClient(config)
        elif config.provider == LLMProvider.OPENAI:
            return OpenAILLMClient(config)
        elif config.provider == LLMProvider.GEMINI:
            return GeminiLLMClient(config)
        elif config.provider == LLMProvider.MOCK:
            return MockLLMClient(config)
        elif config.provider == LLMProvider.OLLAMA:
            return OllamaLLMClient(config)
        elif config.provider == LLMProvider.AZURE:
            return AzureLLMClient(config)
        elif config.provider == LLMProvider.VERTEX_AI:
            return VertexAILLMClient(config)
        else:
            logger.warning(f"Unknown provider {config.provider}, defaulting to Mock")
            return MockLLMClient(config)

    @classmethod
    async def load_from_db(cls) -> None:
        try:
            from db import db
            from services.encryption import decrypt
            doc = await db.llm_config.find_one({"_id": "active"}, {"_id": 0})
            if not doc:
                return
            if doc.get("api_key"):
                doc["api_key"] = decrypt(doc["api_key"])
            cfg = LLMConfig(**doc)
            cls._current_config = cfg
            cls._clients.clear()
            logger.info(f"Loaded LLM config from DB: {cfg.provider.value} ({cfg.model_name})")
        except Exception as e:
            logger.warning(f"Could not load LLM config from DB: {e}")

    @classmethod
    async def save_to_db(cls, config: LLMConfig) -> None:
        try:
            from db import db
            from services.encryption import encrypt
            doc = config.model_dump()
            if doc.get("api_key"):
                doc["api_key"] = encrypt(doc["api_key"])
            await db.llm_config.update_one({"_id": "active"}, {"$set": doc}, upsert=True)
        except Exception as e:
            logger.error(f"Could not persist LLM config: {e}")

    @classmethod
    def update_config(cls, config: LLMConfig):
        cls._current_config = config
        cls._clients.clear()

    @classmethod
    def get_current_config(cls) -> LLMConfig:
        if cls._current_config is None:
            cls._current_config = LLMConfig()
        return cls._current_config

    @classmethod
    async def health_check(cls) -> Dict[str, Any]:
        config = cls.get_current_config()
        client = cls.get_client(config)
        is_healthy = await client.health_check()
        return {
            "provider": config.provider.value,
            "model_name": config.model_name,
            "healthy": is_healthy,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
