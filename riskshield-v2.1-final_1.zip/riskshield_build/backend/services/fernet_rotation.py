"""
Fernet Key Rotation Script
Rotates the RISKSHIELD_ENCRYPTION_KEY without losing existing secrets.

Usage:
    python -m services.fernet_rotation --new-key <base64-key>
    
    Or generate a new key:
    python -m services.fernet_rotation --generate

WARNING: Run this against a backup first. Rotation is irreversible.
"""
import asyncio
import base64
import hashlib
import os
import sys
import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

CIPHER_PREFIX = "enc:v1:"


def derive_fernet_key(raw_key: str):
    from cryptography.fernet import Fernet
    try:
        f = Fernet(raw_key.encode())
        return f
    except Exception:
        derived = base64.urlsafe_b64encode(hashlib.sha256(raw_key.encode()).digest())
        return Fernet(derived)


async def rotate_key(
    db,
    old_key: str,
    new_key: str,
    dry_run: bool = True,
) -> dict:
    """
    Re-encrypt all stored secrets with a new key.
    
    Affected collections and fields:
      - llm_config.api_key
      - servicenow_configs.password, .api_token
    
    Returns a report of how many records were rotated.
    """
    old_fernet = derive_fernet_key(old_key)
    new_fernet = derive_fernet_key(new_key)
    report = {"rotated": 0, "failed": 0, "skipped": 0, "dry_run": dry_run}

    def re_encrypt(ciphertext: Optional[str]) -> Optional[str]:
        if not ciphertext or not ciphertext.startswith(CIPHER_PREFIX):
            return ciphertext  # plaintext passthrough
        token = ciphertext[len(CIPHER_PREFIX):]
        try:
            plaintext = old_fernet.decrypt(token.encode()).decode()
            new_token = new_fernet.encrypt(plaintext.encode()).decode()
            return f"{CIPHER_PREFIX}{new_token}"
        except Exception as e:
            logger.error(f"Re-encryption failed: {e}")
            return None  # signals failure

    # LLM config
    async for doc in db.llm_config.find({}):
        new_val = re_encrypt(doc.get("api_key"))
        if new_val is None:
            report["failed"] += 1
        elif new_val == doc.get("api_key"):
            report["skipped"] += 1
        else:
            if not dry_run:
                await db.llm_config.update_one(
                    {"_id": doc["_id"]}, {"$set": {"api_key": new_val}}
                )
            report["rotated"] += 1

    # ServiceNow configs
    async for doc in db.servicenow_configs.find({}):
        updates = {}
        for field in ["password", "api_token"]:
            val = doc.get(field)
            if val:
                new_val = re_encrypt(val)
                if new_val is None:
                    report["failed"] += 1
                elif new_val != val:
                    updates[field] = new_val
                    report["rotated"] += 1
        if updates and not dry_run:
            await db.servicenow_configs.update_one(
                {"_id": doc["_id"]}, {"$set": updates}
            )

    logger.info(f"Key rotation {'(DRY RUN) ' if dry_run else ''}complete: {report}")
    return report


def generate_key() -> str:
    """Generate a new Fernet key."""
    from cryptography.fernet import Fernet
    return Fernet.generate_key().decode()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="RiskShield Fernet Key Rotation")
    parser.add_argument("--generate", action="store_true", help="Generate a new key and exit")
    parser.add_argument("--new-key", help="New key to rotate to")
    parser.add_argument("--old-key", help="Old key (defaults to RISKSHIELD_ENCRYPTION_KEY env var)")
    parser.add_argument("--dry-run", action="store_true", default=True, help="Simulate only (default: True)")
    parser.add_argument("--apply", action="store_true", help="Actually apply the rotation")
    args = parser.parse_args()

    if args.generate:
        key = generate_key()
        print(f"\n✅ New Fernet key generated:\n   {key}\n")
        print("⚠️  Store this securely and update RISKSHIELD_ENCRYPTION_KEY")
        sys.exit(0)

    if not args.new_key:
        print("❌ --new-key is required. Use --generate to create one.")
        sys.exit(1)

    old_key = args.old_key or os.environ.get("RISKSHIELD_ENCRYPTION_KEY", "riskshield-default-seed-2026")
    dry_run = not args.apply

    async def main():
        from motor.motor_asyncio import AsyncIOMotorClient
        from dotenv import load_dotenv
        load_dotenv()
        client = AsyncIOMotorClient(os.environ.get("MONGO_URL", "mongodb://localhost:27017"))
        db = client[os.environ.get("DB_NAME", "riskshield")]
        report = await rotate_key(db, old_key, args.new_key, dry_run=dry_run)
        print(f"\n{'DRY RUN — ' if dry_run else ''}Key Rotation Report:")
        for k, v in report.items():
            print(f"  {k}: {v}")
        if dry_run:
            print("\n  Run with --apply to commit changes.")
        client.close()

    asyncio.run(main())
