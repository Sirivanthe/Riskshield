"""
Assessment Job Queue
Replaces daemon-thread background tasks with a persistent, crash-safe queue.
Uses MongoDB as the backing store so jobs survive restarts.

In production, migrate to Celery + Redis for horizontal scaling.
"""
import asyncio
import uuid
import logging
from datetime import datetime, timezone
from typing import Any, Callable, Coroutine, Dict, Optional

logger = logging.getLogger(__name__)

JOB_STATUS = {
    "PENDING":    "Queued, not yet started",
    "RUNNING":    "Currently executing",
    "COMPLETED":  "Finished successfully",
    "FAILED":     "Finished with error",
    "CANCELLED":  "Manually cancelled",
}


async def enqueue(
    db,
    job_type: str,
    payload: Dict[str, Any],
    priority: int = 5,
) -> str:
    """Add a job to the queue. Returns the job ID."""
    job_id = str(uuid.uuid4())
    await db.job_queue.insert_one({
        "_id": job_id,
        "job_type": job_type,
        "payload": payload,
        "priority": priority,
        "status": "PENDING",
        "retries": 0,
        "max_retries": 3,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "started_at": None,
        "completed_at": None,
        "error": None,
        "result": None,
    })
    logger.info(f"Job enqueued: {job_id} [{job_type}]")
    return job_id


async def update_job(db, job_id: str, **kwargs) -> None:
    """Update job fields."""
    await db.job_queue.update_one({"_id": job_id}, {"$set": kwargs})


async def get_job(db, job_id: str) -> Optional[Dict]:
    return await db.job_queue.find_one({"_id": job_id}, {"_id": 0})


async def get_pending_jobs(db, limit: int = 10):
    cursor = db.job_queue.find(
        {"status": "PENDING"},
        sort=[("priority", -1), ("created_at", 1)],
    ).limit(limit)
    return await cursor.to_list(length=limit)


async def run_job_worker(db, handlers: Dict[str, Callable]) -> None:
    """
    Simple async worker loop — runs pending jobs from the queue.
    In production, run this as a separate Celery worker process.
    """
    while True:
        try:
            jobs = await get_pending_jobs(db, limit=5)
            for job in jobs:
                job_id = job.get("_id") or job.get("id")
                job_type = job["job_type"]
                handler = handlers.get(job_type)

                if not handler:
                    await update_job(db, job_id, status="FAILED", error=f"No handler for {job_type}")
                    continue

                await update_job(db, job_id, status="RUNNING",
                                 started_at=datetime.now(timezone.utc).isoformat())
                try:
                    result = await handler(db, job["payload"])
                    await update_job(db, job_id, status="COMPLETED",
                                     result=result,
                                     completed_at=datetime.now(timezone.utc).isoformat())
                    logger.info(f"Job completed: {job_id}")
                except Exception as e:
                    retries = job.get("retries", 0) + 1
                    max_retries = job.get("max_retries", 3)
                    if retries < max_retries:
                        await update_job(db, job_id, status="PENDING", retries=retries,
                                         error=str(e))
                        logger.warning(f"Job {job_id} failed (retry {retries}/{max_retries}): {e}")
                    else:
                        await update_job(db, job_id, status="FAILED",
                                         error=str(e),
                                         completed_at=datetime.now(timezone.utc).isoformat())
                        logger.error(f"Job {job_id} permanently failed: {e}")
        except Exception as e:
            logger.error(f"Job worker error: {e}")

        await asyncio.sleep(2)  # Poll every 2s
