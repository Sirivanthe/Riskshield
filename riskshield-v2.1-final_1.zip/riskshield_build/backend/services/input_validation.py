"""
Input Validation & Sanitisation
Guards against LLM prompt injection via user-supplied text fields.
"""
import re
import html
from typing import Optional

# Patterns that could attempt to hijack LLM instructions
_INJECTION_PATTERNS = [
    r"ignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions",
    r"(?:system|assistant)\s*:\s*",
    r"<\s*(?:system|assistant|user)\s*>",
    r"jailbreak",
    r"(?:act|pretend|roleplay)\s+as\s+(?:an?\s+)?(?:evil|unethical|unrestricted)",
    r"DAN\s+mode",
    r"developer\s+mode",
]
_INJECTION_RE = re.compile("|".join(_INJECTION_PATTERNS), re.IGNORECASE)

# Max lengths per field type
LIMITS = {
    "name":        200,
    "title":       300,
    "description": 8000,
    "text":        20000,
    "short":       100,
}


def sanitise(value: Optional[str], field_type: str = "text") -> str:
    """Strip HTML, truncate to limit, and flag injection attempts."""
    if not value:
        return ""
    # Decode HTML entities then strip tags
    cleaned = html.unescape(value)
    cleaned = re.sub(r"<[^>]+>", "", cleaned)
    # Truncate
    limit = LIMITS.get(field_type, 8000)
    cleaned = cleaned[:limit]
    return cleaned


def check_injection(value: Optional[str]) -> bool:
    """Return True if the value appears to contain a prompt injection attempt."""
    if not value:
        return False
    return bool(_INJECTION_RE.search(value))


def validate_assessment_input(data: dict) -> tuple[dict, list]:
    """Validate and sanitise assessment creation input. Returns (clean_data, errors)."""
    errors = []
    clean = {}

    name = sanitise(data.get("name", ""), "name")
    if not name:
        errors.append("Assessment name is required")
    elif check_injection(name):
        errors.append("Assessment name contains invalid content")
    else:
        clean["name"] = name

    clean["system_name"]   = sanitise(data.get("system_name", ""), "name")
    clean["business_unit"] = sanitise(data.get("business_unit", ""), "short")
    clean["description"]   = sanitise(data.get("description", ""), "description")

    if check_injection(clean.get("description", "")):
        errors.append("Description contains invalid content")

    frameworks = data.get("frameworks", [])
    if isinstance(frameworks, list):
        clean["frameworks"] = [f for f in frameworks if isinstance(f, str)][:10]
    else:
        clean["frameworks"] = []

    return clean, errors


def validate_control_input(data: dict) -> tuple[dict, list]:
    """Validate control create/update input."""
    errors = []
    clean = {}

    name = sanitise(data.get("name", ""), "name")
    if not name:
        errors.append("Control name is required")
    else:
        clean["name"] = name

    clean["description"]    = sanitise(data.get("description", ""), "description")
    clean["test_procedure"] = sanitise(data.get("test_procedure", ""), "description")
    clean["owner"]          = sanitise(data.get("owner", ""), "short")
    clean["domain"]         = sanitise(data.get("domain", ""), "short")

    valid_categories = {"PREVENTIVE", "DETECTIVE", "CORRECTIVE"}
    if data.get("category") in valid_categories:
        clean["category"] = data["category"]

    valid_types = {"TECHNICAL", "ADMINISTRATIVE", "PHYSICAL"}
    if data.get("type") in valid_types:
        clean["type"] = data["type"]

    if check_injection(clean.get("description", "")) or check_injection(clean.get("test_procedure", "")):
        errors.append("Control fields contain invalid content")

    return clean, errors


def validate_issue_input(data: dict) -> tuple[dict, list]:
    """Validate issue create/update input."""
    errors = []
    clean = {}

    title = sanitise(data.get("title", ""), "title")
    if not title:
        errors.append("Issue title is required")
    else:
        clean["title"] = title

    clean["description"] = sanitise(data.get("description", ""), "description")
    clean["owner"]       = sanitise(data.get("owner", ""), "short")

    valid_severities = {"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"}
    if data.get("severity") in valid_severities:
        clean["severity"] = data["severity"]

    valid_priorities = {"CRITICAL", "HIGH", "MEDIUM", "LOW"}
    if data.get("priority") in valid_priorities:
        clean["priority"] = data["priority"]

    return clean, errors
