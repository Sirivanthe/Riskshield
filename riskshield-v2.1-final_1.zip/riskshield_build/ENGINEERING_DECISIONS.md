# RiskShield — Engineering Decisions & Product Recommendations

*As of v2.1.0 — April 2026*

---

## Completed in v2.1 (This Release)

| # | Decision | Rationale |
|---|---|---|
| 1 | Removed Emergent platform dependency | Vendor lock-in risk; Emergent's `emergentintegrations` package is not on PyPI and requires their proprietary key. Direct SDKs are stable, testable, and give full cost visibility. |
| 2 | Rate limiting via in-process token bucket | No Redis dependency for local dev. Swap to Redis-backed SlideWindow in production for multi-process deployments. |
| 3 | SQLite for local dev, MongoDB for production | Eliminates MongoDB requirement for first-run experience. Schema is 1:1 compatible — same API surface. |
| 4 | WAL mode on SQLite | Allows concurrent reads during background assessment writes without lock contention. |
| 5 | Audit log never breaks main request | `try/except` wrapper on `write_audit` — a logging failure must never return 500 to the user. |
| 6 | Control history: before/after snapshots | Regulators (RBI, FCA) require evidence of who changed what and when. Full snapshot is more expensive than field-diff but simpler to query and present in audits. |
| 7 | Job queue in DB not daemon threads | Daemon threads lose jobs on crash/restart. DB-backed queue survives restarts and supports retry logic. Production path: Celery + Redis. |
| 8 | Structured error responses with error codes | Enables frontend to handle errors programmatically (e.g. show different UI for `RATE_LIMITED` vs `INVALID_TOKEN`). Never leaks stack traces. |
| 9 | Pagination on all list endpoints | Without pagination, `GET /issues` in a bank with 10,000+ issues would timeout. Default limit=20 is safe. |
| 10 | Prompt injection defence at API layer | Defence-in-depth: even if a malicious payload reaches the API, it's blocked before the LLM call. Regex-based for speed; add ML-based classifier in v2.2. |

---

## Recommended Next Steps (Prioritised)

### P0 — Do Before Any Production Traffic

**1. SSO / SAML Integration**
Banks will not accept password-based auth in production. Their IT policies mandate SSO through Okta, Azure AD, or Ping Identity.
- Implementation: Add `python-saml` or `authlib` OAuth2/OIDC library
- Estimated effort: 1 sprint
- Blocker for: every enterprise customer

**2. Evidence File Storage**
The platform references "evidence uploads" but has no file storage backend. Files need S3-compatible object storage (AWS S3, Azure Blob, MinIO).
- Implementation: Add `boto3` client, pre-signed URL upload flow
- Estimated effort: 3 days
- Blocker for: Control Analysis, RCM Testing (currently stores only text references)

**3. Replace In-Process Rate Limiter with Redis**
The current token bucket is per-process. With 2+ uvicorn workers (production), each worker has its own bucket — effective limit becomes `N × 10 req/min`. Use Redis with a sliding window.
- Implementation: `redis-py` + `slowapi` library
- Estimated effort: 1 day

**4. Real-Time Assessment Status via WebSocket**
Assessment status currently polls every 5s. Replace with Server-Sent Events or WebSocket for instant feedback.
- Implementation: FastAPI native WebSocket support already available
- Estimated effort: 2 days

### P1 — Next Sprint

**5. Celery + Redis Job Queue**
Replace the SQLite job queue with Celery for true horizontal scaling. Background assessment jobs should run on dedicated worker processes.
- Implementation: `celery[redis]`, add `celery.py` worker entry point
- Estimated effort: 1 week
- Benefit: jobs survive backend restarts, can scale workers independently

**6. FAISS Index Persistence on Restart**
The vector store currently rebuilds on restart because FAISS is loaded from `data/faiss_index/`. The Docker volume mount exists but the load-on-startup path needs verification. Add a health check that confirms index is loaded.

**7. API Key Rotation UI**
The Fernet key rotation script exists (`scripts/rotate-key.sh`) but requires SSH access. Add an Admin UI flow: upload new key → dry run preview → confirm apply → restart prompt.

**8. MongoDB Index Review**
`server.py` creates indexes on startup but the index on `audit_log.timestamp` is missing from the production init. A bank with 6 months of audit events (potentially millions of rows) will hit full collection scans without it.

**9. Multi-Process DB Connection Pool**
`motor` (async MongoDB driver) creates one connection pool per process. With Celery workers + uvicorn workers, audit the total connection count against MongoDB's `maxIncomingConnections` limit.

### P2 — Quarter

**10. What-If Risk Simulations**
Already in PRD backlog. Implement as: user selects a scenario (e.g. "MFA disabled on 30% of accounts"), platform runs agent to re-score risk register and show delta. Useful for board presentations.

**11. Compliance-as-Code CI Pipeline**
Run the automated control testing agents in GitHub Actions / Azure DevOps on every PR. Fail the pipeline if a critical control drops below effectiveness threshold.

**12. Real-Time Collaboration**
Two auditors editing the same assessment create race conditions. Add optimistic locking (`version` field + `If-Match` header) at minimum. Full collaboration requires Operational Transformation or CRDTs.

**13. Advanced Analytics**
The current Trend Analytics uses synthetic data. Connect to real DB query aggregations. Add: risk heat maps, control gap matrix, regulatory coverage chart, SLA breach prediction.

**14. PDF Report Branding**
The `pdf_report_generator.py` generates basic PDF reports. Add bank logo injection, custom colour scheme, and executive summary page — key for board presentations.

---

## Architecture Debt (Must Address Before Scale)

| Issue | Impact | Fix |
|---|---|---|
| `server.py` is 2,400 lines | Unmaintainable, merge conflicts | Split into route modules (already started in `/routes/`) |
| No API versioning | Breaking changes affect all clients | Add `/api/v2/` prefix, maintain v1 for 1 release |
| No request tracing | Can't correlate logs across services | Propagate `X-Request-ID` into MongoDB queries and LLM calls |
| Secrets in env vars | 12-factor OK, but no rotation workflow | Add HashiCorp Vault or AWS Secrets Manager integration |
| No DB migration framework | Schema changes break production | Add `pymongo-migrate` or custom migration runner |
| FAISS in-process | Can't scale horizontally | Extract to a dedicated embedding service with REST API |

---

## Security Posture — Banking Context

| Control | Status | Gap |
|---|---|---|
| Auth rate limiting | ✅ 10 req/min per IP | Needs Redis for multi-process |
| Password policy | ⚠️ Min 8 chars only | Add complexity + breach check (HaveIBeenPwned API) |
| MFA | ❌ Not implemented | Required for bank production — TOTP via `pyotp` |
| SSO | ❌ Not implemented | Required for bank production |
| Secrets at rest | ✅ Fernet encryption | Key rotation UI missing |
| Audit log | ✅ Immutable, all events | Export to SIEM missing (CEF/syslog format) |
| TLS | ⚠️ Handled by nginx in prod | Ensure mutual TLS for internal service calls |
| Input validation | ✅ Injection detection | Add WAF in front of API (AWS WAF, Cloudflare) |
| RBAC | ✅ LOD1/LOD2/Admin | No attribute-based AC (ABAC) for fine-grained control |
| GDPR | ✅ GDPR reset endpoint | No data residency enforcement, no retention policy |
| Penetration testing | ❌ Not done | Required before bank go-live |
