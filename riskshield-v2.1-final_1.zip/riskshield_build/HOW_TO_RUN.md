# How to Run RiskShield Locally

Two options — pick one:

| Option | Stack | Time to start |
|---|---|---|
| **A — Docker (recommended)** | MongoDB + FastAPI + React, fully containerised | ~5 min first run |
| **B — Manual** | MongoDB separately, Python directly, React dev server | ~10 min |

---

## Option A — Docker (recommended)

### Prerequisites
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running
- That's it

### 1. Set up your environment file

```bash
cd riskshield_build/backend
cp .env.example .env
```

Open `backend/.env` and fill in these two values (everything else has safe defaults):

```bash
# Generate encryption key — run this and paste the output:
python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

# Generate JWT secret — run this and paste the output:
python3 -c "import secrets; print(secrets.token_urlsafe(48))"
```

Your `.env` should look like:
```
MONGO_URL=mongodb://mongo:27017
DB_NAME=riskshield
JWT_SECRET=<your generated value>
RISKSHIELD_ENCRYPTION_KEY=<your generated value>
ANTHROPIC_API_KEY=          ← leave blank for MOCK mode, or add your key
```

### 2. Start everything

```bash
cd riskshield_build
docker compose -f deploy/docker-compose.yml up -d
```

First run downloads images and builds containers (~3-5 min). Subsequent starts take ~10 seconds.

### 3. Verify it's running

```bash
docker compose -f deploy/docker-compose.yml ps
```

All three services should show `healthy` or `running`:
```
NAME                    STATUS
riskshield-mongo        running (healthy)
riskshield-backend      running (healthy)
riskshield-frontend     running
```

```bash
# Quick API check
curl http://localhost:8001/api/
```

### 4. Open the app

→ **http://localhost:3000**

### 5. Log in

| Role | Email | Password |
|---|---|---|
| Admin | admin@bank.com | admin123 |
| Risk Owner (LOD1) | lod1@bank.com | password123 |
| Compliance (LOD2) | lod2@bank.com | password123 |

### Stop

```bash
docker compose -f deploy/docker-compose.yml down
# To also delete all data:
docker compose -f deploy/docker-compose.yml down -v
```

---

## Option B — Manual (MongoDB + Python + Node)

### Prerequisites
- Python 3.10+
- Node.js 18+
- MongoDB 6+ running locally (`brew install mongodb-community` / `apt install mongodb`)

### 1. Start MongoDB

```bash
mongod --dbpath /tmp/riskshield-db
# or if installed as a service:
brew services start mongodb-community
```

### 2. Set up the backend

```bash
cd riskshield_build/backend
cp .env.example .env
# Edit .env — change MONGO_URL to mongodb://localhost:27017
```

Generate your keys:
```bash
python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
python3 -c "import secrets; print(secrets.token_urlsafe(48))"
```

Install dependencies:
```bash
pip install -r requirements.txt
```

Start the backend:
```bash
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### 3. Set up the frontend

```bash
cd riskshield_build/frontend
echo "REACT_APP_BACKEND_URL=http://localhost:8001" > .env
npm install --legacy-peer-deps
npm start
```

Browser opens at **http://localhost:3000**

---

## Add real AI (Anthropic Claude)

Add your key to `backend/.env`:
```
ANTHROPIC_API_KEY=sk-ant-api03-...
```

Then restart:
```bash
# Docker:
docker compose -f deploy/docker-compose.yml restart backend

# Manual:
# Ctrl+C the uvicorn process, then: uvicorn server:app --host 0.0.0.0 --port 8001
```

Or switch provider live in the UI without restarting: **Admin → LLM Configuration**

---

## Test it from the terminal

```bash
# Login and get token
TOKEN=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@bank.com","password":"admin123"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

# Health check
curl http://localhost:8001/api/

# Create a risk assessment
curl -s -X POST http://localhost:8001/api/assessments \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"Core Banking Risk Review","system_name":"T24","frameworks":["NIST CSF","ISO 27001","RBI"]}' \
  | python3 -m json.tool

# List controls (seeded on first start)
curl -s "http://localhost:8001/api/control-analysis/controls?page=1&limit=10" \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

# Create an issue
curl -s -X POST http://localhost:8001/api/issues \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"MFA not enforced on admin accounts","severity":"HIGH","priority":"HIGH"}' \
  | python3 -m json.tool

# View audit log (admin only)
curl -s "http://localhost:8001/api/audit-log?page=1" \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `docker: command not found` | Install [Docker Desktop](https://docs.docker.com/get-docker/) |
| Port 3000 or 8001 already in use | `lsof -ti:3000 | xargs kill` or change ports in docker-compose.yml |
| Backend says `EMERGENT_LLM_KEY not set` | This should not happen in v2.1. Delete and re-unzip the package. |
| Frontend shows blank page | Wait 30s for backend health check to pass, then hard-refresh |
| `ModuleNotFoundError` (manual mode) | `pip install -r requirements.txt` in the backend folder |
| MongoDB connection refused (manual) | Check mongod is running: `mongosh` |
| Assessment stuck `IN_PROGRESS` | Normal without API key — add `ANTHROPIC_API_KEY` or check logs |
| Docker build fails on faiss-cpu | Needs 2GB+ RAM in Docker Desktop settings |

---

## What gets created on first start

MongoDB collections seeded automatically:
- **users** — 3 demo users (admin, lod1, lod2)
- **custom_controls** — 8 example controls (MFA, Encryption, Vuln Management…)
- All other collections start empty

Data persists in the `mongo-data` Docker volume between restarts.
