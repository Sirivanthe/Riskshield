#!/usr/bin/env bash
# RiskShield Platform — Local Setup Script
# Usage: bash scripts/setup.sh

set -e

echo ""
echo "🛡️  RiskShield Platform Setup"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check Python
python3 --version >/dev/null 2>&1 || { echo "❌ Python 3.10+ required"; exit 1; }
echo "✅ Python: $(python3 --version)"

# Check Node (optional for frontend)
if node --version >/dev/null 2>&1; then
    echo "✅ Node: $(node --version)"
else
    echo "⚠️  Node.js not found — frontend build will be skipped"
fi

# Generate encryption key if not set
if [ ! -f backend/.env ]; then
    echo ""
    echo "📋 Creating backend/.env from template..."
    cp backend/.env.example backend/.env
    
    # Generate a real Fernet key
    ENC_KEY=$(python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())" 2>/dev/null || echo "")
    if [ -n "$ENC_KEY" ]; then
        sed -i "s|RISKSHIELD_ENCRYPTION_KEY=|RISKSHIELD_ENCRYPTION_KEY=$ENC_KEY|" backend/.env
        echo "✅ Generated RISKSHIELD_ENCRYPTION_KEY"
    fi
    
    # Generate JWT secret
    JWT=$(python3 -c "import secrets; print(secrets.token_urlsafe(48))" 2>/dev/null || echo "riskshield-$(date +%s)")
    sed -i "s|JWT_SECRET=change-this-to-a-long-random-secret-in-production|JWT_SECRET=$JWT|" backend/.env
    echo "✅ Generated JWT_SECRET"
    
    echo ""
    echo "⚙️  Edit backend/.env to add your API keys:"
    echo "   ANTHROPIC_API_KEY=sk-ant-..."
    echo "   (Platform works in MOCK mode without any API key)"
fi

# Install backend deps (if pip available and connected)
echo ""
echo "📦 Checking backend dependencies..."
if pip install --quiet flask cryptography PyJWT python-dotenv 2>/dev/null; then
    echo "✅ Core dependencies available"
else
    echo "⚠️  pip install skipped (no internet or already installed)"
fi

# Install frontend deps
if [ -d "frontend" ] && command -v npm >/dev/null 2>&1; then
    echo ""
    echo "📦 Installing frontend dependencies..."
    cd frontend && npm install --legacy-peer-deps --silent && cd ..
    echo "✅ Frontend dependencies installed"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Setup complete!"
echo ""
echo "▶  To start: bash scripts/start.sh"
echo "   Backend:  http://localhost:8001"
echo "   Frontend: http://localhost:3000"
echo ""
echo "🔑 Default credentials:"
echo "   admin@bank.com  / admin123"
echo "   lod1@bank.com   / password123"  
echo "   lod2@bank.com   / password123"
echo ""
