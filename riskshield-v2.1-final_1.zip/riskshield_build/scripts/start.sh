#!/usr/bin/env bash
# RiskShield Platform — Start Script
# Usage: bash scripts/start.sh [--no-frontend] [--port 8001]

set -e

BACKEND_PORT=${BACKEND_PORT:-8001}
FRONTEND_PORT=${FRONTEND_PORT:-3000}
NO_FRONTEND=false

for arg in "$@"; do
    case $arg in
        --no-frontend) NO_FRONTEND=true ;;
        --port) BACKEND_PORT="$2"; shift ;;
    esac
done

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo ""
echo "🛡️  Starting RiskShield Platform v2.1"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Load env
if [ -f backend/.env ]; then
    set -a; source backend/.env; set +a
    echo "✅ Environment loaded"
fi

# Start backend
echo "🚀 Starting backend on port $BACKEND_PORT..."
cd backend
python3 local_server.py &
BACKEND_PID=$!
echo "   PID: $BACKEND_PID"
cd "$ROOT_DIR"

# Wait for backend
sleep 2
if curl -sf "http://localhost:$BACKEND_PORT/api/" >/dev/null 2>&1; then
    echo "✅ Backend healthy: http://localhost:$BACKEND_PORT"
else
    echo "⚠️  Backend may still be starting..."
fi

# Start frontend
if [ "$NO_FRONTEND" = false ] && [ -d "frontend/node_modules" ]; then
    echo "🚀 Starting frontend on port $FRONTEND_PORT..."
    cd frontend
    BROWSER=none PORT=$FRONTEND_PORT npm start &
    FRONTEND_PID=$!
    echo "   PID: $FRONTEND_PID"
    cd "$ROOT_DIR"
    echo "✅ Frontend starting: http://localhost:$FRONTEND_PORT"
elif [ "$NO_FRONTEND" = false ]; then
    echo "⚠️  Frontend node_modules not found — run 'bash scripts/setup.sh' first"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🛡️  RiskShield is running!"
echo ""
echo "   API:      http://localhost:$BACKEND_PORT"
echo "   UI:       http://localhost:$FRONTEND_PORT"
echo "   API Docs: http://localhost:$BACKEND_PORT/docs"
echo ""
echo "   Credentials: admin@bank.com / admin123"
echo ""
echo "Press Ctrl+C to stop."
echo ""

# Wait and handle shutdown
cleanup() {
    echo ""
    echo "🛑 Shutting down..."
    kill $BACKEND_PID 2>/dev/null || true
    kill $FRONTEND_PID 2>/dev/null || true
    echo "✅ Stopped."
    exit 0
}
trap cleanup INT TERM

wait
