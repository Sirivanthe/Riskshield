#!/usr/bin/env bash
echo "🛑 Stopping RiskShield..."
pkill -f "local_server.py" 2>/dev/null && echo "✅ Backend stopped" || echo "ℹ️  Backend not running"
pkill -f "react-scripts start" 2>/dev/null && echo "✅ Frontend stopped" || echo "ℹ️  Frontend not running"
