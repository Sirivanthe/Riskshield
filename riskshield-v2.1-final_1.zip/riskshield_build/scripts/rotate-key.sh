#!/usr/bin/env bash
# RiskShield — Fernet Key Rotation Helper
# Usage: bash scripts/rotate-key.sh [--apply]

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR/backend"

echo "🔐 RiskShield Key Rotation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$1" = "--generate" ] || [ -z "$1" ]; then
    echo "Generating new Fernet key..."
    python3 -m services.fernet_rotation --generate
    echo ""
    echo "Steps to rotate:"
    echo "1. Copy the new key above"
    echo "2. Run: bash scripts/rotate-key.sh --dry-run --new-key <KEY>"
    echo "3. If output looks good: bash scripts/rotate-key.sh --apply --new-key <KEY>"
    echo "4. Update RISKSHIELD_ENCRYPTION_KEY in backend/.env"
    echo "5. Restart the platform"
elif [ "$1" = "--dry-run" ]; then
    shift
    python3 -m services.fernet_rotation --dry-run "$@"
elif [ "$1" = "--apply" ]; then
    shift
    echo "⚠️  WARNING: This will re-encrypt all stored secrets. Backup your DB first."
    read -p "Continue? (yes/no): " confirm
    if [ "$confirm" = "yes" ]; then
        python3 -m services.fernet_rotation --apply "$@"
    else
        echo "Cancelled."
    fi
fi
